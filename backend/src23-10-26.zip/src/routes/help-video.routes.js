const router = require('express').Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const authenticate = require('../middleware/authenticate');
const c = require('../controllers/help-video.controller');

const uploadDir = path.join(__dirname, '../../uploads/help-videos');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const unique = `crm_help_${Date.now()}${ext}`;
    cb(null, unique);
  },
});

// Allow up to 500MB video files
const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const allowed = ['.mp4', '.webm', '.mov', '.mkv', '.avi', '.m4v'];
    if (allowed.includes(ext) || file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files (.mp4, .webm, .mov, etc.) are allowed.'));
    }
  },
});

// All routes require authentication
router.use(authenticate);

// Publicly accessible to all logged in users
router.get('/', c.getHelpVideo);

// Admin-only management
router.post('/', (req, res, next) => {
  if (req.is('multipart/form-data')) {
    upload.single('video')(req, res, next);
  } else {
    next();
  }
}, c.saveHelpVideo);
router.put('/', c.updateHelpVideoDetails);
router.delete('/:id', c.deleteHelpVideo);
router.delete('/', c.deleteHelpVideo);

module.exports = router;
