require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const { runMigrations } = require('./src/db/migrate');
const { handleWhatsappWebhook } = require('./src/webhooks/whatsapp');
const { handleFacebookWebhook } = require('./src/webhooks/facebook');
const { handleInstagramWebhook } = require('./src/webhooks/instagram');
const { handleRazorpayWebhook, handleStripeWebhook } = require('./src/webhooks/payments');
const { handleBrevoWebhook } = require('./src/webhooks/brevo');
const { handleIncomingCall, handleKeyPress } = require('./src/controllers/ivr.controller');
const { redirect } = require('./src/controllers/ctwa.controller');
const { handleOptInLink } = require('./src/controllers/contacts.controller');
const { startBroadcastJob } = require('./src/jobs/broadcastJob');
const { startDripJob } = require('./src/jobs/dripJob');
const { startSmsJob } = require('./src/jobs/smsJob');
const r2Service = require('./src/services/r2.service');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*', methods: ['GET', 'POST'] } });

// Store io on app for controller access
app.set('io', io);

// Middleware
app.use(cors({
  origin: function (origin, callback) {
    callback(null, true);
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept', 'Origin', 'Access-Control-Request-Method', 'Access-Control-Request-Headers']
}));
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: false }));
app.use(morgan('dev'));
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true }));

// Static files
const assetStaticOptions = {
  setHeaders: (res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
  }
};
app.use('/assets', express.static(path.join(__dirname, 'src', 'assets'), assetStaticOptions));
app.use('/src/assets', express.static(path.join(__dirname, 'src', 'assets'), assetStaticOptions));
app.use('/backend/src/assets', express.static(path.join(__dirname, 'src', 'assets'), assetStaticOptions));

app.use('/uploads', express.static(path.join(__dirname, 'uploads'), {
  setHeaders: (res, filePath) => {
    // Allow any origin to fetch uploaded media (required for cross-origin and ngrok)
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Type');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    
    // Fix for WhatsApp API: Ensure correct MIME type for audio files
    if (filePath.endsWith('.ogg')) {
      res.setHeader('Content-Type', 'audio/ogg; codecs=opus');
    } else if (filePath.endsWith('.webm')) {
      res.setHeader('Content-Type', 'audio/webm; codecs=opus');
    } else if (filePath.endsWith('.m4a') || filePath.endsWith('.mp4')) {
      res.setHeader('Content-Type', 'audio/mp4');
    }
  }
}));

// Cloudflare R2 streaming fallback for /uploads/*
app.use('/uploads', async (req, res, next) => {
  if (!r2Service.isConfigured()) return next();
  try {
    const rawKey = req.path.replace(/^\/+/, '');
    if (!rawKey) return next();

    // Check if file exists in R2
    let targetKey = null;
    if (await r2Service.exists(rawKey)) {
      targetKey = rawKey;
    } else if (await r2Service.exists(`uploads/${rawKey}`)) {
      targetKey = `uploads/${rawKey}`;
    }

    if (!targetKey) {
      return res.status(404).send('File not found in storage');
    }

    const { body, contentType, contentLength, lastModified } = await r2Service.getObjectStream(targetKey);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Type');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
    if (contentType) res.setHeader('Content-Type', contentType);
    if (contentLength) res.setHeader('Content-Length', contentLength);
    if (lastModified) res.setHeader('Last-Modified', new Date(lastModified).toUTCString());

    // Fix for WhatsApp API MIME types
    if (targetKey.endsWith('.ogg')) res.setHeader('Content-Type', 'audio/ogg; codecs=opus');
    else if (targetKey.endsWith('.webm')) res.setHeader('Content-Type', 'audio/webm; codecs=opus');
    else if (targetKey.endsWith('.mp3')) res.setHeader('Content-Type', 'audio/mp3');
    else if (targetKey.endsWith('.m4a') || targetKey.endsWith('.mp4')) res.setHeader('Content-Type', 'audio/mp4');

    body.pipe(res);
  } catch (streamErr) {
    console.error('Cloudflare R2 stream error:', streamErr);
    next();
  }
});

// Public routes
app.get('/c/:shortCode', redirect);
app.get('/optin/:token', handleOptInLink);

// Webhook routes (no auth)
app.get('/api/webhooks/whatsapp', (req, res) => handleWhatsappWebhook(req, res, io));
app.post('/api/webhooks/whatsapp', (req, res) => handleWhatsappWebhook(req, res, io));
app.get('/api/webhooks/facebook', (req, res) => handleFacebookWebhook(req, res, io));
app.post('/api/webhooks/facebook', (req, res) => handleFacebookWebhook(req, res, io));
app.get('/api/webhooks/instagram', (req, res) => handleInstagramWebhook(req, res, io));
app.post('/api/webhooks/instagram', (req, res) => handleInstagramWebhook(req, res, io));
app.post('/api/webhooks/brevo', (req, res) => handleBrevoWebhook(req, res, io));
app.get('/api/webhooks/brevo', (req, res) => res.status(200).send('Brevo webhook active'));
app.post('/api/webhooks/razorpay', handleRazorpayWebhook);
app.post('/api/webhooks/stripe', handleStripeWebhook);
app.post('/api/webhooks/ivr/incoming', handleIncomingCall);
app.post('/api/webhooks/ivr/keypress', handleKeyPress);

// API routes
app.use('/api/company-config', require('./src/routes/company-config.routes'));
app.use('/api/auth', require('./src/routes/auth.routes'));
app.use('/api/contacts', require('./src/routes/contacts.routes'));
app.use('/api', require('./src/routes/leads.routes'));
app.use('/api/conversations', require('./src/routes/conversations.routes'));
app.use('/api/templates', require('./src/routes/templates.routes'));
app.use('/api/broadcasts', require('./src/routes/broadcasts.routes'));
app.use('/api/upload', require('./src/routes/upload.routes'));
app.use('/api/chatbots', require('./src/routes/chatbots.routes'));
app.use('/api/drip', require('./src/routes/drip.routes'));
app.use('/api/ecommerce', require('./src/routes/ecommerce.routes'));
app.use('/api/ctwa', require('./src/routes/ctwa.routes'));
app.use('/api/widget', require('./src/routes/widget.routes'));
app.use('/api/rcs', require('./src/routes/rcs.routes'));
app.use('/api/sms', require('./src/routes/sms.routes'));
app.use('/api/ivr', require('./src/routes/ivr.routes'));
app.use('/api/integrations', require('./src/routes/integrations.routes'));
app.use('/api/analytics', require('./src/routes/analytics.routes'));
app.use('/api/affiliates', require('./src/routes/affiliates.routes'));
app.use('/api/settings', require('./src/routes/settings.routes'));
app.use('/api/system-settings', require('./src/routes/system-settings.routes'));
app.use('/api/country-codes', require('./src/routes/country-codes.routes'));
app.use('/api/media-library', require('./src/routes/media-library.routes'));
app.use('/api/courses', require('./src/routes/courses.routes'));
app.use('/api/universities', require('./src/routes/universities.routes'));
app.use('/api/attendance', require('./src/routes/attendance.routes'));
app.use('/api/applications', require('./src/routes/applications.routes'));
app.use('/api/reports', require('./src/routes/reports.routes'));
app.use('/api/timeline', require('./src/routes/timeline.routes'));
app.use('/api/notifications', require('./src/routes/notifications.routes'));
app.use('/api/receipts', require('./src/routes/receipts.routes'));
app.use('/api/qualifications', require('./src/routes/contact_qualifications/contact_qualifications.routes'));
app.use('/api/work-experiences', require('./src/routes/contact_work_experiences/contact_work_experiences.routes'));
app.use('/api/contact-tasks', require('./src/routes/contact_tasks/contact_tasks.routes'));
app.use('/api/visas', require('./src/routes/visas.routes'));
app.use('/api/pte', require('./src/routes/pte.routes'));
app.use('/api/help-video', require('./src/routes/help-video.routes'));
app.use('/api/export', require('./src/routes/excel-export'));

// WhatsApp QR routes (enabled only if ENABLE_WHATSAPP_QR=1)
if (process.env.ENABLE_WHATSAPP_QR === '1') {
  app.use('/api/whatsapp-qr', require('./src/routes/whatsapp/whatsappQr.routes'));
} else {
  app.use('/api/whatsapp-qr', (req, res) => {
    res.status(503).json({
      success: false,
      message: 'WhatsApp QR service is disabled. Set ENABLE_WHATSAPP_QR=1 in .env to enable.'
    });
  });
}
// app.use('/api/operations', require('./src/routes/operations.routes'));

// Socket.IO
io.on('connection', (socket) => {
  console.log('🔌 Socket connected:', socket.id);
  socket.on('join_business', (businessId) => {
    socket.join(`biz_${businessId}`);
    console.log(`Socket ${socket.id} joined biz_${businessId}`);
  });
  socket.on('disconnect', () => console.log('Socket disconnected:', socket.id));
});

// Health check
app.get('/api/health', (req, res) => res.json({ success: true, message: 'Trackbox API is running', data: { version: '1.0.0' } }));

// Start
const PORT = process.env.PORT || 3000;

async function bootstrap() {
  try {
    await runMigrations();

    // WhatsApp QR socket & active session restoration (controlled by ENABLE_WHATSAPP_QR=1)
    if (process.env.ENABLE_WHATSAPP_QR === '1') {
      try {
        const { initWhatsappQrSocket } = require('./src/sockets/whatsapp/whatsappQr.socket');
        const { autoResumeActiveSessions } = require('./src/services/whatsapp/baileysSession.service');
        initWhatsappQrSocket(io);
        await autoResumeActiveSessions(io);
        console.log('📱 WhatsApp QR service initialized');
      } catch (qrErr) {
        console.error('⚠️ Failed to initialize WhatsApp QR service:', qrErr.message);
      }
    } else {
      console.log('ℹ️ WhatsApp QR service is disabled (ENABLE_WHATSAPP_QR != 1)');
    }

    startBroadcastJob(io);
    startDripJob(io);
    startSmsJob();
    server.listen(PORT, () => console.log(`🚀 Trackbox API running on port ${PORT}`));
  } catch (err) {
    console.error('❌ Startup error:', err);
    process.exit(1);
  }
}

bootstrap();
