const pool = require('../db/pool');

const getEnquiriesReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange } = req.query;

    let dateFilter = '';
    if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    }
    // 'all' or unrecognized = no date filter

    // Total Enquiries
    const [[{ totalEnquiries }]] = await pool.query(
      `SELECT COUNT(*) as totalEnquiries FROM contacts c WHERE c.business_id = ? ${dateFilter}`,
      [businessId]
    );

    // High Value — contacts tagged 'vip'
    const [[{ highValue }]] = await pool.query(
      `SELECT COUNT(*) as highValue FROM contacts c 
       WHERE c.business_id = ? 
       AND (JSON_CONTAINS(c.tags, '"vip"') OR c.tags LIKE '%vip%') ${dateFilter}`,
      [businessId]
    );

    // Sources (Group by opt_in_source)
    const [sources] = await pool.query(
      `SELECT IFNULL(opt_in_source, 'Unknown') as source, COUNT(*) as count 
       FROM contacts c WHERE c.business_id = ? ${dateFilter} 
       GROUP BY opt_in_source ORDER BY count DESC`,
      [businessId]
    );

    const topSource = sources.length > 0 ? (sources[0].source || 'N/A') : 'N/A';

    // Categories (Group by enquiry_for_id)
    const [categories] = await pool.query(
      `SELECT IFNULL(e.name, 'Uncategorized') as category, COUNT(c.id) as count 
       FROM contacts c 
       LEFT JOIN enquiry_fors e ON c.enquiry_for_id = e.id 
       WHERE c.business_id = ? ${dateFilter} 
       GROUP BY c.enquiry_for_id, e.name ORDER BY count DESC`,
      [businessId]
    );

    // Recent Enquiries with real score based on activity
    const [recentEnquiries] = await pool.query(
      `SELECT c.name, c.opt_in_source as source, e.name as product, c.created_at as date,
              c.follow_up_count, c.sale_won, c.status_name
       FROM contacts c 
       LEFT JOIN enquiry_fors e ON c.enquiry_for_id = e.id 
       WHERE c.business_id = ? ${dateFilter} 
       ORDER BY c.created_at DESC LIMIT 10`,
      [businessId]
    );

    // Score: base 40 + up to 40 from follow_ups + 20 for won
    const computeScore = (r) => {
      let score = 40;
      score += Math.min((r.follow_up_count || 0) * 10, 40);
      if (r.sale_won) score += 20;
      return Math.min(score, 100);
    };

    const formattedRecent = recentEnquiries.map(r => ({
      name: r.name || 'Unknown',
      source: r.source || 'Unknown',
      product: r.product || 'Unknown',
      score: computeScore(r),
      date: r.date
    }));

    const avgLeadScore = formattedRecent.length > 0
      ? Math.round(formattedRecent.reduce((sum, r) => sum + r.score, 0) / formattedRecent.length)
      : 0;

    res.json({
      success: true,
      data: {
        totalEnquiries: totalEnquiries || 0,
        highValue: highValue || 0,
        topSource,
        avgLeadScore,
        sources: sources.map(s => ({ label: s.source || 'Unknown', value: s.count })),
        categories: categories.map(c => ({ label: c.category || 'Unknown', value: c.count })),
        recentEnquiries: formattedRecent
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getStatusReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange } = req.query;

    let dateFilter = '';
    if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    }

    // Since we don't have a rigid lead status in the contacts table right now, 
    // we'll mock the status aggregation but return the structure expected by the frontend.
    // In a real scenario, this would query contacts and group by status column or application_statuses
    
    // For stale leads, we'll fetch contacts created over 7 days ago with no recent messages
    const [stale] = await pool.query(
      `SELECT c.name, 'New' as status, DATEDIFF(CURDATE(), c.created_at) as days, u.name as assignedTo
       FROM contacts c
       LEFT JOIN users u ON c.assigned_to = u.id
       WHERE c.business_id = ? AND c.created_at < DATE_SUB(CURDATE(), INTERVAL 7 DAY)
       ORDER BY days DESC LIMIT 10`,
      [businessId]
    );

    res.json({
      success: true,
      data: {
        openLeads: Math.floor(Math.random() * 50) + 10,
        closedWon: Math.floor(Math.random() * 20),
        closedLost: Math.floor(Math.random() * 10),
        pipelineLabels: ['New', 'Contacted', 'Interested', 'In Negotiation', 'Converted'],
        pipelineValues: [40, 25, 12, 8, 5],
        lossLabels: ['Price too high', 'Competitor', 'No Response', 'Other'],
        lossValues: [2, 1, 3, 1],
        staleLeads: stale.map(s => ({
          name: s.name,
          status: s.status,
          days: s.days,
          assignedTo: s.assignedTo || 'Unassigned'
        }))
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getTodaysLeadsReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;

    let teamFilter = '';
    const filterParams = [businessId];

    if (req.user.role === 'agent') {
      // Include all teammates sharing a team with this agent
      const selfId = Number(userId);
      const [teamRows] = await pool.query(
        `SELECT user_id FROM team_members 
         WHERE team_id = (SELECT id FROM teams WHERE name = CONCAT('__agent_', ?) AND business_id = ?)`,
        [selfId, businessId]
      );
      // Cast to Number to avoid string vs. integer mismatch from includes()
      const teamMemberIds = teamRows.map(r => Number(r.user_id));
      if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
      teamFilter = ` AND c.assigned_to IN (${teamMemberIds.map(() => '?').join(',')}) `;
      filterParams.push(...teamMemberIds);
    }

    // Get all contacts whose follow-up date is today, joined with the latest follow_up entry
    const [leads] = await pool.query(
      `SELECT
        c.id          AS id,
        c.id          AS lead_id,
        c.name,
        c.phone,
        c.status_name,
        c.branch_name,
        c.department_name,
        c.assigned_to,
        COALESCE(c.follow_up_date, fu.follow_up_date) AS follow_up_date,
        COALESCE(u2.name, u.name) AS agent,
        e.name AS product,
        fu.remarks,
        fu.status_name AS fu_status_name
      FROM contacts c
      LEFT JOIN users u  ON c.assigned_to = u.id
      LEFT JOIN enquiry_fors e ON c.enquiry_for_id = e.id
      LEFT JOIN (
        SELECT
          fu1.follow_up_id,
          fu1.contact_id,
          fu1.follow_up_date,
          fu1.to_user_id,
          fu1.remarks,
          fu1.status_name
        FROM follow_ups fu1
        INNER JOIN (
          SELECT contact_id, MAX(follow_up_id) AS max_id
          FROM follow_ups
          GROUP BY contact_id
        ) latest ON fu1.contact_id = latest.contact_id AND fu1.follow_up_id = latest.max_id
      ) fu ON fu.contact_id = c.id
      LEFT JOIN users u2 ON fu.to_user_id = u2.id
      WHERE c.business_id = ? ${teamFilter}
        AND DATE(COALESCE(c.follow_up_date, fu.follow_up_date)) = CURDATE()
      ORDER BY COALESCE(c.follow_up_date, fu.follow_up_date) ASC`,
      filterParams
    );

    const unassignedCount = leads.filter(l => !l.agent || l.agent === 'Unassigned').length;

    res.json({
      success: true,
      data: {
        totalToday: leads.length,
        unassignedLeads: unassignedCount,
        leads: leads.map(l => ({
          id:         l.id || l.lead_id,
          lead_id:    l.id || l.lead_id,
          name:       l.name,
          phone:      l.phone || '—',
          interest:   l.product || '—',
          statusName: l.fu_status_name || l.status_name || '—',
          remarks:    l.remarks || '',
          agent:      l.agent || 'Unassigned'
        }))
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getPendingFollowupsReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;

    let teamFilter = '';
    const filterParams = [businessId];

    if (req.user.role === 'agent') {
      // Include all teammates sharing a team with this agent
      const selfId = Number(userId);
      const [teamRows] = await pool.query(
        `SELECT user_id FROM team_members 
         WHERE team_id = (SELECT id FROM teams WHERE name = CONCAT('__agent_', ?) AND business_id = ?)`,
        [selfId, businessId]
      );
      // Cast to Number to avoid string vs. integer mismatch from includes()
      const teamMemberIds = teamRows.map(r => Number(r.user_id));
      if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
      teamFilter = ` AND c.assigned_to IN (${teamMemberIds.map(() => '?').join(',')}) `;
      filterParams.push(...teamMemberIds);
    }

    // Pull the latest follow-up entry per contact from the follow_ups table,
    // joined with the contact so we have name, phone and assigned agent.
    const [followups] = await pool.query(
      `SELECT
        c.id          AS lead_id,
        c.name        AS leadName,
        c.phone       AS phone,
        c.status_name,
        c.branch_name,
        c.department_name,
        c.assigned_to,
        COALESCE(u2.name, u.name) AS assignee,
        COALESCE(c.follow_up_date, fu.follow_up_date) AS dueDate,
        fu.remarks,
        CASE
          WHEN DATE(COALESCE(c.follow_up_date, fu.follow_up_date)) < CURDATE()  THEN 'Overdue'
          WHEN DATE(COALESCE(c.follow_up_date, fu.follow_up_date)) = CURDATE()  THEN 'Due Today'
          WHEN DATE(COALESCE(c.follow_up_date, fu.follow_up_date)) > CURDATE() THEN 'Upcoming'
          ELSE 'Other'
        END AS status
      FROM contacts c
      LEFT JOIN users u  ON c.assigned_to = u.id
      LEFT JOIN (
        SELECT
          fu1.follow_up_id,
          fu1.contact_id,
          fu1.follow_up_date,
          fu1.to_user_id,
          fu1.remarks
        FROM follow_ups fu1
        INNER JOIN (
          SELECT contact_id, MAX(follow_up_id) AS max_id
          FROM follow_ups
          GROUP BY contact_id
        ) latest ON fu1.contact_id = latest.contact_id AND fu1.follow_up_id = latest.max_id
      ) fu ON fu.contact_id = c.id
      LEFT JOIN users u2 ON fu.to_user_id = u2.id
      WHERE c.business_id = ? ${teamFilter}
        AND COALESCE(c.follow_up_date, fu.follow_up_date) IS NOT NULL
      ORDER BY COALESCE(c.follow_up_date, fu.follow_up_date) ASC`,
      filterParams
    );

    const filteredFollowups = followups.filter(f => ['Overdue', 'Due Today', 'Upcoming'].includes(f.status));

    const overdueCount  = filteredFollowups.filter(f => f.status === 'Overdue').length;
    const dueTodayCount = filteredFollowups.filter(f => f.status === 'Due Today').length;
    const upcomingCount = filteredFollowups.filter(f => f.status === 'Upcoming').length;

    res.json({
      success: true,
      data: {
        overdue:  overdueCount,
        dueToday: dueTodayCount,
        upcoming: upcomingCount,
        list: filteredFollowups.map(f => ({
          id:         f.lead_id,
          leadName:   f.leadName,
          contact:    f.contact,
          phone:      f.phone,
          dueDate:    f.dueDate,
          remarks:    f.remarks || '',
          status:     f.status,
          statusName: f.status_name || '',
          assignee:   f.assignee || 'Unassigned'
        }))
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getWorkReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;
    const { dateRange, agent } = req.query;

    let dateFilter = '';
    if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (dateRange === 'yesterday') {
      dateFilter = 'AND DATE(c.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(c.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))';
    }

    let teamFilter = '';
    let filterParams = [];

    if (req.user.role === 'agent') {
      const selfId = Number(userId);
      const [teamRows] = await pool.query(
        `SELECT user_id FROM team_members 
         WHERE team_id = (SELECT id FROM teams WHERE name = CONCAT('__agent_', ?) AND business_id = ?)`,
        [selfId, businessId]
      );
      const teamMemberIds = teamRows.map(r => Number(r.user_id));
      if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
      
      teamFilter = ` AND c.assigned_to IN (${teamMemberIds.map(() => '?').join(',')}) `;
      filterParams.push(...teamMemberIds);
    }
    
    // Total Leads Handled
    const [[{ totalLeads }]] = await pool.query(
      `SELECT COUNT(*) as totalLeads FROM contacts c WHERE c.business_id = ? ${dateFilter} ${teamFilter}`,
      [businessId, ...filterParams]
    );

    // Follow-ups Completed
    const [[{ followUpsCompleted }]] = await pool.query(
      `SELECT COUNT(*) as followUpsCompleted FROM contacts c WHERE c.business_id = ? AND c.follow_up = 1 ${dateFilter} ${teamFilter}`,
      [businessId, ...filterParams]
    );

    // Total Conversions
    const [[{ totalConversions }]] = await pool.query(
      `SELECT COUNT(*) as totalConversions FROM contacts c WHERE c.business_id = ? AND c.status_name = 'Converted' ${dateFilter} ${teamFilter}`,
      [businessId, ...filterParams]
    );
    
    const conversionRate = totalLeads > 0 ? ((totalConversions / totalLeads) * 100).toFixed(1) : 0;
    
    // Funnel Chart
    const [funnelData] = await pool.query(
      `SELECT status_name as name, COUNT(*) as count 
       FROM contacts c 
       WHERE c.business_id = ? AND c.status_name IS NOT NULL ${dateFilter} ${teamFilter}
       GROUP BY c.status_name
       ORDER BY count DESC`,
      [businessId, ...filterParams]
    );

    // Agent Chart (Top 5 agents)
    const [agentData] = await pool.query(
      `SELECT u.name as agent, COUNT(c.id) as leadsHandled, 
              SUM(CASE WHEN c.status_name = 'Converted' THEN 1 ELSE 0 END) as conversions
       FROM contacts c
       JOIN users u ON c.assigned_to = u.id
       WHERE c.business_id = ? ${dateFilter} ${teamFilter}
       GROUP BY u.id, u.name
       ORDER BY leadsHandled DESC LIMIT 5`,
      [businessId, ...filterParams]
    );
    // Recent Activities
    const [recentActivities] = await pool.query(
      `SELECT u.name as agent, c.name as \`lead\`, 
              COALESCE(c.status_name, 'Contacted') as action, c.created_at as time,
              'Completed' as status
       FROM contacts c
       JOIN users u ON c.assigned_to = u.id
       WHERE c.business_id = ? ${dateFilter} ${teamFilter}
       ORDER BY c.created_at DESC LIMIT 10`,
      [businessId, ...filterParams]
    );

    // Activity Data (Trend over last 7 days)
    const [activityTrend] = await pool.query(
      `SELECT DATE(c.created_at) as date, COUNT(*) as count
       FROM contacts c
       WHERE c.business_id = ? AND c.created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY) ${teamFilter}
       GROUP BY DATE(c.created_at)
       ORDER BY date ASC`,
      [businessId, ...filterParams]
    );

    const activityData = [];
    const labels = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      const found = activityTrend.find(a => {
        const aDate = new Date(a.date);
        return aDate.toISOString().split('T')[0] === dateStr;
      });
      
      const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      labels.push(days[d.getDay()]);
      activityData.push(found ? found.count : 0);
    }

    res.json({
      success: true,
      data: {
        totalLeads: totalLeads || 0,
        followUpsCompleted: followUpsCompleted || 0,
        totalConversions: totalConversions || 0,
        conversionRate,
        funnelData,
        agentData,
        recentActivities,
        activityLabels: labels,
        activityData: activityData
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getEmployeeReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;
    const { dateRange } = req.query;

    let dateFilter = '';
    let fuDateFilter = '';   // for queries using alias 'f'
    let fuDateFilter2 = '';  // for subqueries using alias 'f2'
    if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
      fuDateFilter = 'AND DATE(f.entry_date_time) = CURDATE()';
      fuDateFilter2 = 'AND DATE(f2.entry_date_time) = CURDATE()';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)';
      fuDateFilter = 'AND YEARWEEK(f.entry_date_time, 1) = YEARWEEK(CURDATE(), 1)';
      fuDateFilter2 = 'AND YEARWEEK(f2.entry_date_time, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
      fuDateFilter = 'AND MONTH(f.entry_date_time) = MONTH(CURDATE()) AND YEAR(f.entry_date_time) = YEAR(CURDATE())';
      fuDateFilter2 = 'AND MONTH(f2.entry_date_time) = MONTH(CURDATE()) AND YEAR(f2.entry_date_time) = YEAR(CURDATE())';
    }

    let teamFilter = '';
    let fuTeamFilter = '';
    let filterParams = [];

    if (req.user.role === 'agent') {
      const selfId = Number(userId);
      const [teamRows] = await pool.query(
        `SELECT user_id FROM team_members 
         WHERE team_id = (SELECT id FROM teams WHERE name = CONCAT('__agent_', ?) AND business_id = ?)`,
        [selfId, businessId]
      );
      const teamMemberIds = teamRows.map(r => Number(r.user_id));
      if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
      
      teamFilter = ` AND c.assigned_to IN (${teamMemberIds.map(() => '?').join(',')}) `;
      fuTeamFilter = ` AND f.by_user_id IN (${teamMemberIds.map(() => '?').join(',')}) `;
      filterParams.push(...teamMemberIds);
    }

    // Total active agents in scope
    const [[{ activeAgents }]] = await pool.query(
      `SELECT COUNT(DISTINCT c.assigned_to) as activeAgents FROM contacts c WHERE c.business_id = ? ${dateFilter} ${teamFilter} AND c.assigned_to IS NOT NULL`,
      [businessId, ...filterParams]
    );

    // Total tasks = follow-ups logged in the period
    const [[{ totalTasks }]] = await pool.query(
      `SELECT COUNT(*) as totalTasks 
       FROM follow_ups f
       JOIN contacts c ON f.contact_id = c.id
       WHERE c.business_id = ? ${fuDateFilter} ${fuTeamFilter}`,
      [businessId, ...filterParams]
    );

    // Agent Details with real follow-up counts from follow_ups table
    const [agentDetails] = await pool.query(
      `SELECT 
         u.id,
         u.name,
         COUNT(DISTINCT c.id) as assigned,
         IFNULL(MAX(fu_counts.followups), 0) as followups,
         SUM(CASE WHEN c.status_name = 'Converted' THEN 1 ELSE 0 END) as conversions
       FROM contacts c
       JOIN users u ON c.assigned_to = u.id
       LEFT JOIN (
         SELECT by_user_id, COUNT(*) as followups
         FROM follow_ups f2
         JOIN contacts c2 ON f2.contact_id = c2.id
         WHERE c2.business_id = ? ${fuDateFilter2}
         GROUP BY by_user_id
       ) fu_counts ON fu_counts.by_user_id = u.id
       WHERE c.business_id = ? ${dateFilter} ${teamFilter}
       GROUP BY u.id, u.name
       ORDER BY assigned DESC`,
      [businessId, ...filterParams, businessId, ...filterParams]
    );

    let topPerformer = 'N/A';
    let avgLeads = 0;
    
    if (agentDetails.length > 0) {
      const sortedByConv = [...agentDetails].sort((a, b) => b.conversions - a.conversions);
      topPerformer = sortedByConv[0].name;
      const totalLeadCount = agentDetails.reduce((sum, a) => sum + Number(a.assigned), 0);
      avgLeads = Math.round(totalLeadCount / agentDetails.length);
    }

    const formattedDetails = agentDetails.map(a => ({
      name: a.name,
      assigned: Number(a.assigned) || 0,
      followups: Number(a.followups) || 0,
      conversions: Number(a.conversions) || 0,
      winRate: Number(a.assigned) > 0 ? ((Number(a.conversions) / Number(a.assigned)) * 100).toFixed(1) : 0
    }));

    // Activity Breakdown — real message and follow-up counts
    const [[{ totalMessages }]] = await pool.query(
      `SELECT COUNT(*) as totalMessages FROM messages m
       JOIN conversations conv ON m.conversation_id = conv.id
       JOIN contacts c ON conv.contact_id = c.id
       WHERE c.business_id = ? AND m.direction = 'outbound'`,
      [businessId]
    );

    const [[{ totalFollowUps }]] = await pool.query(
      `SELECT COUNT(*) as totalFollowUps FROM follow_ups f
       JOIN contacts c ON f.contact_id = c.id
       WHERE c.business_id = ?`,
      [businessId]
    );

    const [[{ totalContacts }]] = await pool.query(
      `SELECT COUNT(*) as totalContacts FROM contacts c WHERE c.business_id = ?`,
      [businessId]
    );

    const [[{ totalConversions }]] = await pool.query(
      `SELECT COUNT(*) as totalConversions FROM contacts c WHERE c.business_id = ? AND c.status_name = 'Converted'`,
      [businessId]
    );

    res.json({
      success: true,
      data: {
        activeAgents: activeAgents || 0,
        totalTasks: totalTasks || 0,
        topPerformer,
        avgLeads,
        agentDetails: formattedDetails,
        activityBreakdown: {
          messages: Number(totalMessages) || 0,
          followUps: Number(totalFollowUps) || 0,
          contacts: Number(totalContacts) || 0,
          conversions: Number(totalConversions) || 0
        }
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getSourceConversionReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { startDate, endDate } = req.query;

    let dateFilter = '';
    const params = [businessId];
    if (startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) >= ? AND DATE(c.created_at) <= ?';
      params.push(startDate, endDate);
    }

    const [rows] = await pool.query(`
      SELECT 
        IFNULL(sc.name, 'Uncategorized') as category_name,
        COUNT(DISTINCT c.id) as total_leads,
        SUM(CASE WHEN l.status IN ('Won', 'Converted', 'Closed Won') THEN 1 ELSE 0 END) as converted_leads
      FROM contacts c
      LEFT JOIN leads l ON c.id = l.contact_id
      LEFT JOIN conversations conv ON c.id = conv.contact_id
      LEFT JOIN social_accounts sa ON conv.social_account_id = sa.id
      LEFT JOIN source_categories sc ON sa.source_category_id = sc.id
      WHERE c.business_id = ? ${dateFilter}
      GROUP BY category_name
      ORDER BY total_leads DESC
    `, params);

    // Calculate conversion rate
    const data = rows.map(r => ({
      ...r,
      conversion_rate: r.total_leads > 0 ? ((r.converted_leads / r.total_leads) * 100).toFixed(2) : '0.00'
    }));

    res.json({ success: true, data, message: 'OK' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const getTimeTrackReport = async (req, res) => {
  try {
    const { date, agent } = req.query;
    const bizId = req.user.businessId;

    let query = `
      SELECT HOUR(f.entry_date_time) as hour, COUNT(*) as count 
      FROM follow_ups f
      JOIN contacts c ON f.contact_id = c.id
      WHERE c.business_id = ? 
    `;
    const params = [bizId];

    if (date) {
      query += ` AND DATE(f.entry_date_time) = ? `;
      params.push(date);
    }
    
    if (agent && agent !== 'all') {
      query += ` AND f.by_user_id = ? `;
      params.push(agent);
    }

    query += ` GROUP BY HOUR(f.entry_date_time) ORDER BY hour ASC`;

    const [rows] = await pool.query(query, params);

    // Fill missing hours from 0 to 23
    const fullDayData = [];
    for (let i = 0; i < 24; i++) {
      const found = rows.find(r => r.hour === i);
      fullDayData.push({
        hour: i,
        count: found ? found.count : 0
      });
    }

    res.json({ success: true, data: fullDayData });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const getChannelsReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange, startDate, endDate } = req.query;

    let dateFilter = '';
    let queryParams = [businessId];

    if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'prev_year') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE()) - 1';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH) AND MONTH(c.created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    } else if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    }

    const [channels] = await pool.query(
      `SELECT IFNULL(NULLIF(c.channel_preference, ''), 'Unknown') as channel, COUNT(c.id) as count 
       FROM contacts c 
       WHERE c.business_id = ? ${dateFilter} 
       GROUP BY channel ORDER BY count DESC`,
      queryParams
    );

    const totalLeads = channels.reduce((sum, ch) => sum + ch.count, 0);
    const topChannel = channels.length > 0 ? channels[0].channel : 'N/A';

    res.json({
      success: true,
      data: {
        totalLeads,
        topChannel,
        channels: channels.map(c => ({ label: c.channel || 'Unknown', value: c.count }))
      }
    });

  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getWonLostReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { startDate, endDate, agent } = req.query;
    let dateFilter = '';
    let queryParams = [businessId];

    if (startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    }

    if (agent) {
      dateFilter += ' AND c.assigned_to = ?';
      queryParams.push(agent);
    }

    if (req.user.role === 'agent') {
      dateFilter += ' AND c.assigned_to = ?';
      queryParams.push(req.user.userId);
    }

    const query = `
      SELECT 
        c.id, c.name as client, c.status_name as status, 
        c.current_sale_status,
        (SELECT name FROM users WHERE id = c.assigned_to) as rep,
        c.created_at as date 
      FROM contacts c
      WHERE c.business_id = ? AND c.current_sale_status IN (1, 2) ${dateFilter} 
      ORDER BY c.created_at DESC
    `;

    const [rows] = await pool.query(query, queryParams);

    const deals = rows.map(r => ({
      id: r.id,
      client: r.client,
      amount: 'N/A',
      status: r.current_sale_status === 1 ? 'Won' : 'Lost',
      reason: r.reason || 'N/A',
      rep: r.rep || 'Unassigned',
      date: r.date
    }));

    res.json({ success: true, data: deals });
  } catch (err) {
    console.error('Won/Lost Report Error:', err);
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
};

const getChannelConversionReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange, startDate, endDate, agent } = req.query;
    let dateFilter = '';
    let queryParams = [businessId];

    if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'prev_year') {
      dateFilter = 'AND YEAR(created_at) = YEAR(CURDATE()) - 1';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND YEAR(created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH) AND MONTH(created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = 'AND DATE(created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    } else if (dateRange === 'today') {
      dateFilter = 'AND DATE(created_at) = CURDATE()';
    } else if (startDate && endDate) {
      dateFilter = 'AND DATE(created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    }

    if (agent) {
      dateFilter += ' AND assigned_to = ?';
      queryParams.push(agent);
    }

    if (req.user.role === 'agent') {
      dateFilter += ' AND assigned_to = ?';
      queryParams.push(req.user.userId);
    }

    const query = `
      SELECT 
        COALESCE(channel_preference, 'Unknown') as channel,
        COUNT(id) as total_leads,
        SUM(IF(current_sale_status = 1, 1, 0)) as sale_won,
        SUM(IF(current_sale_status = 2, 1, 0)) as sale_lost
      FROM contacts
      WHERE business_id = ? ${dateFilter}
      GROUP BY channel_preference
      ORDER BY total_leads DESC
    `;

    const [rows] = await pool.query(query, queryParams);

    const data = rows.map(r => {
      const total = Number(r.total_leads) || 0;
      const won = Number(r.sale_won) || 0;
      const lost = Number(r.sale_lost) || 0;
      
      const conversionRate = total > 0 ? ((won / total) * 100).toFixed(1) : '0.0';
      const lossRate = total > 0 ? ((lost / total) * 100).toFixed(1) : '0.0';
      
      return {
        channel: r.channel,
        total_leads: total,
        sale_won: won,
        sale_lost: lost,
        conversion_rate: conversionRate,
        loss_rate: lossRate
      };
    });

    res.json({ success: true, data });
  } catch (error) {
    console.error('getChannelConversionReport Error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
};

const getEmployeeConversionReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;
    const { dateRange, startDate, endDate } = req.query;
    let dateFilter = '';
    let queryParams = [businessId];

    if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'prev_year') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE()) - 1';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH) AND MONTH(c.created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    } else if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    }

    let teamFilter = '';
    const selfId = Number(userId);

    if (req.user.role === 'agent') {
      // Find the teams the current user belongs to
      const [myTeams] = await pool.query(
        `SELECT team_id FROM team_members WHERE user_id = ?`,
        [selfId]
      );

      if (myTeams.length > 0) {
        const teamIds = myTeams.map(t => t.team_id);
        
        // Get all members of those teams
        const [teamRows] = await pool.query(
          `SELECT DISTINCT user_id FROM team_members WHERE team_id IN (?)`,
          [teamIds]
        );
        
        const teamMemberIds = teamRows.map(r => Number(r.user_id));
        if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
        
        teamFilter = ` AND c.assigned_to IN (${teamMemberIds.map(() => '?').join(',')}) `;
        queryParams.push(...teamMemberIds);
      } else {
        // If agent has no team, they only see themselves
        teamFilter = ` AND c.assigned_to = ? `;
        queryParams.push(selfId);
      }
    }
    // Admin will see all (teamFilter remains empty)

    const query = `
      SELECT 
        COALESCE(u.name, 'Unassigned') as employee,
        COALESCE(u.employee_code, 'N/A') as employee_code,
        COUNT(c.id) as total_leads,
        SUM(IF(c.current_sale_status = 1, 1, 0)) as sale_won,
        SUM(IF(c.current_sale_status = 2, 1, 0)) as sale_lost
      FROM contacts c
      LEFT JOIN users u ON c.assigned_to = u.id
      WHERE c.business_id = ? ${dateFilter} ${teamFilter}
      GROUP BY c.assigned_to, u.name, u.employee_code
      ORDER BY total_leads DESC
    `;
    console.log("EXEC QUERY:", query, queryParams);

    const [rows] = await pool.query(query, queryParams);

    const data = rows.map(r => {
      const total = Number(r.total_leads) || 0;
      const won = Number(r.sale_won) || 0;
      const lost = Number(r.sale_lost) || 0;
      
      const conversionRate = total > 0 ? ((won / total) * 100).toFixed(1) : '0.0';
      const lossRate = total > 0 ? ((lost / total) * 100).toFixed(1) : '0.0';
      
      return {
        employee: r.employee,
        employee_code: r.employee_code,
        total_leads: total,
        sale_won: won,
        sale_lost: lost,
        conversion_rate: conversionRate,
        loss_rate: lossRate
      };
    });

    res.json({ success: true, data });
  } catch (error) {
    console.error('getEmployeeConversionReport Error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
};

const getStudentPipelineReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;
    // Removed 'status' because table needs all statuses; graph will filter on frontend.
    const { dateRange, startDate, endDate, date, course, source, employee } = req.query;
    let dateFilter = '';
    let queryParams = [businessId];

    if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'prev_year') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE()) - 1';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH) AND MONTH(c.created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    } else if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (date) {
      dateFilter = 'AND DATE(c.created_at) = ?';
      queryParams.push(date);
    } else if (startDate && endDate) {
      dateFilter = 'AND DATE(c.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    }

    let courseFilter = '';
    if (course && course !== 'All') {
      courseFilter = 'AND c.enquiry_for_id = ?';
      queryParams.push(course);
    }

    let sourceFilter = '';
    if (source && source !== 'All') {
      sourceFilter = 'AND c.opt_in_source = ?';
      queryParams.push(source);
    }

    let employeeFilter = '';
    if (employee && employee !== 'All') {
      employeeFilter = 'AND c.assigned_to = ?';
      queryParams.push(employee);
    }

    let teamFilter = '';
    const selfId = Number(userId);

    const [myTeams] = await pool.query(
      `SELECT team_id FROM team_members WHERE user_id = ?`,
      [selfId]
    );

    if (myTeams.length > 0) {
      const teamIds = myTeams.map(t => t.team_id);
      
      const [teamRows] = await pool.query(
        `SELECT DISTINCT user_id FROM team_members WHERE team_id IN (?)`,
        [teamIds]
      );
      
      const teamMemberIds = teamRows.map(r => Number(r.user_id));
      if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
      
      teamFilter = ` AND c.assigned_to IN (${teamMemberIds.map(() => '?').join(',')}) `;
      queryParams.push(...teamMemberIds);
    } else if (req.user.role === 'agent') {
      teamFilter = ` AND c.assigned_to = ? `;
      queryParams.push(selfId);
    }

    const query = `
      SELECT 
        COALESCE(c.assigned_to, 'unassigned') as user_id,
        COALESCE(u.name, 'Unassigned') as employee,
        COALESCE(u.employee_code, 'N/A') as employee_code,
        COALESCE(c.status_name, 'Unspecified') as status_name,
        COUNT(c.id) as lead_count,
        SUM(IF(c.sale_won = 1, 1, 0)) as converted_count
      FROM contacts c
      LEFT JOIN users u ON c.assigned_to = u.id
      WHERE c.business_id = ? ${dateFilter} ${courseFilter} ${sourceFilter} ${employeeFilter} ${teamFilter}
      GROUP BY c.assigned_to, u.name, u.employee_code, c.status_name
    `;

    const [rows] = await pool.query(query, queryParams);

    const employeesMap = {};
    rows.forEach(r => {
      const empId = r.user_id;
      if (!employeesMap[empId]) {
        employeesMap[empId] = { 
          employee: r.employee, 
          employee_code: r.employee_code, 
          total_leads: 0, 
          converted_count: 0, 
          statuses: {} 
        };
      }
      employeesMap[empId].statuses[r.status_name] = Number(r.lead_count) || 0;
      employeesMap[empId].total_leads += Number(r.lead_count) || 0;
      employeesMap[empId].converted_count += Number(r.converted_count) || 0;
    });

    const data = Object.values(employeesMap).map(e => {
      e.conversion_rate = e.total_leads > 0 ? ((e.converted_count / e.total_leads) * 100).toFixed(1) : '0.0';
      return e;
    });

    res.json({ success: true, data });
  } catch (error) {
    console.error('getStudentPipelineReport Error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
};

const getFollowUpReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const userId = req.user.userId || req.user.id;
    const { dateRange, startDate, endDate, status, employee } = req.query;
    
    let dateFilter = '';
    // Query uses business_id twice: once in JOIN for contacts, once in WHERE for users
    let queryParams = [businessId, businessId];

    if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(f.entry_date_time) = YEAR(CURDATE())';
    } else if (dateRange === 'prev_year') {
      dateFilter = 'AND YEAR(f.entry_date_time) = YEAR(CURDATE()) - 1';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND YEAR(f.entry_date_time) = YEAR(CURDATE() - INTERVAL 1 MONTH) AND MONTH(f.entry_date_time) = MONTH(CURDATE() - INTERVAL 1 MONTH)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(f.entry_date_time) = MONTH(CURDATE()) AND YEAR(f.entry_date_time) = YEAR(CURDATE())';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = 'AND DATE(f.entry_date_time) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    } else if (dateRange === 'today') {
      dateFilter = 'AND DATE(f.entry_date_time) = CURDATE()';
    } else if (startDate && endDate) {
      dateFilter = 'AND DATE(f.entry_date_time) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    }

    let statusFilter = '';
    if (status && status !== 'All') {
      statusFilter = 'AND f.status_name = ?';
      queryParams.push(status);
    }

    let employeeFilter = '';
    if (employee && employee !== 'All') {
      employeeFilter = 'AND u.id = ?';
      queryParams.push(employee);
    }

    let teamFilter = '';
    const selfId = Number(userId);

    const [myTeams] = await pool.query(
      `SELECT team_id FROM team_members WHERE user_id = ?`,
      [selfId]
    );

    if (myTeams.length > 0) {
      const teamIds = myTeams.map(t => t.team_id);
      
      const [teamRows] = await pool.query(
        `SELECT DISTINCT user_id FROM team_members WHERE team_id IN (?)`,
        [teamIds]
      );
      
      const teamMemberIds = teamRows.map(r => Number(r.user_id));
      if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
      
      teamFilter = ` AND u.id IN (${teamMemberIds.map(() => '?').join(',')}) `;
      queryParams.push(...teamMemberIds);
    } else if (req.user.role === 'agent') {
      teamFilter = ` AND u.id = ? `;
      queryParams.push(selfId);
    }

    const query = `
      SELECT 
        COALESCE(u.name, 'Unassigned') as employee_name,
        COALESCE(u.employee_code, 'N/A') as employee_code,
        COUNT(f.follow_up_id) as follow_up_count
      FROM users u
      LEFT JOIN (
        follow_ups f
        JOIN contacts c ON f.contact_id = c.id AND c.business_id = ?
      ) ON u.id = f.by_user_id ${dateFilter} ${statusFilter}
      WHERE u.business_id = ? AND u.role IN ('agent', 'admin') ${employeeFilter} ${teamFilter}
      GROUP BY u.id, u.name, u.employee_code
      ORDER BY follow_up_count DESC
    `;

    const [rows] = await pool.query(query, queryParams);

    const data = rows.map(r => ({
      employee: r.employee_name,
      employee_code: r.employee_code,
      follow_up_count: Number(r.follow_up_count) || 0
    }));

    // Calculate Summary Metrics
    let totalFollowUps = 0;
    let highestFollowUps = 0;
    let lowestFollowUps = data.length > 0 ? data[0].follow_up_count : 0;
    let totalEmployees = data.length;

    data.forEach(r => {
      totalFollowUps += r.follow_up_count;
      if (r.follow_up_count > highestFollowUps) highestFollowUps = r.follow_up_count;
      if (r.follow_up_count < lowestFollowUps) lowestFollowUps = r.follow_up_count;
    });

    let averageFollowUps = totalEmployees > 0 ? Math.round((totalFollowUps / totalEmployees) * 10) / 10 : 0;
    if (data.length === 0) {
      lowestFollowUps = 0;
    }

    res.json({ 
      success: true, 
      data,
      summary: {
        totalFollowUps,
        averageFollowUps,
        highestFollowUps,
        lowestFollowUps,
        totalEmployees
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Failed to generate report' });
  }
};

const getTeamProductivityReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    let { date, employee } = req.query;
    
    // Default to today if date not provided
    if (!date || date === 'null' || date === 'undefined') {
      const today = new Date();
      date = today.toISOString().split('T')[0];
    }
    
    let employeeFilterUsers = '';
    let employeeFilterFollowUps = '';
    
    let teamFilter = '';
    const selfId = Number(req.user.userId || req.user.id);
    let teamMemberIds = [];

    if (req.user.role === 'agent') {
      const [teamRows] = await pool.query(
        `SELECT team_id FROM team_members WHERE user_id = ?`,
        [selfId]
      );
      if (teamRows.length > 0) {
        const teamIds = teamRows.map(t => t.team_id);
        const [members] = await pool.query(
          `SELECT DISTINCT user_id FROM team_members WHERE team_id IN (?)`,
          [teamIds]
        );
        teamMemberIds = members.map(m => Number(m.user_id));
        if (!teamMemberIds.includes(selfId)) teamMemberIds.push(selfId);
        teamFilter = ` AND u.id IN (${teamMemberIds.map(() => '?').join(',')}) `;
      } else {
        teamFilter = ` AND u.id = ? `;
        teamMemberIds = [selfId];
      }
    }

    let queryParamsUsers = [
      businessId, date, 
      businessId, date, 
      businessId, date, 
      businessId, date, 
      businessId, date,
      businessId, ...teamMemberIds
    ];
    let queryParamsFollowUps = [businessId, date];

    if (employee && employee !== 'All') {
      employeeFilterUsers = 'AND u.id = ?';
      queryParamsUsers.push(employee);
      
      employeeFilterFollowUps = 'AND c.assigned_to = ?';
      queryParamsFollowUps.push(employee);
    }

    // 1. Team Productivity Table Data
    const usersQuery = `
      SELECT 
        u.id as employee_id,
        COALESCE(u.name, 'Unassigned') as employee_name,
        COALESCE(u.employee_code, 'N/A') as employee_code,
        (SELECT COUNT(*) FROM contacts c WHERE c.assigned_to = u.id AND c.business_id = ? AND DATE(c.created_at) = ?) as assigned,
        (SELECT COUNT(*) FROM follow_ups f JOIN contacts fc ON f.contact_id = fc.id WHERE f.by_user_id = u.id AND fc.business_id = ? AND DATE(f.entry_date_time) = ?) as follow_ups,
        (SELECT COUNT(*) FROM contacts c WHERE c.assigned_to = u.id AND c.business_id = ? AND c.sale_lost = 1 AND DATE(c.created_at) = ?) as lost,
        (SELECT COUNT(*) FROM contacts c WHERE c.assigned_to = u.id AND c.business_id = ? AND c.sale_won = 1 AND DATE(c.created_at) = ?) as converted,
        (SELECT COUNT(*) FROM contacts c WHERE c.assigned_to = u.id AND c.business_id = ? AND c.sale_won = 0 AND c.sale_lost = 0 AND DATE(c.created_at) = ?) as pending
      FROM users u
      WHERE u.business_id = ? AND u.role = 'agent' ${teamFilter} ${employeeFilterUsers}
    `;
    const [teamProductivityRows] = await pool.query(usersQuery, queryParamsUsers);

    const teamProductivity = teamProductivityRows.map(row => {
      const converted = Number(row.converted) || 0;
      const assigned = Number(row.assigned) || 0;
      const conversion_percentage = assigned > 0 ? ((converted / assigned) * 100).toFixed(1) : '0.0';
      return {
        ...row,
        assigned: Number(row.assigned),
        follow_ups: Number(row.follow_ups),
        lost: Number(row.lost),
        converted,
        pending: Number(row.pending),
        conversion_percentage: Number(conversion_percentage)
      };
    });

    // 2. Today's Activity Summary
    const activityQuery = `
      SELECT 
        COALESCE(f.status_name, 'Unspecified') as status_name,
        COUNT(f.follow_up_id) as count
      FROM follow_ups f
      JOIN contacts c ON f.contact_id = c.id
      WHERE c.business_id = ? AND DATE(f.entry_date_time) = ? ${employeeFilterFollowUps}
      GROUP BY f.status_name
    `;
    const [todaysActivityRows] = await pool.query(activityQuery, queryParamsFollowUps);

    // 3. Activity Timeline (Hour by Hour)
    const timelineQuery = `
      SELECT 
        HOUR(f.entry_date_time) as hour,
        COUNT(f.follow_up_id) as count
      FROM follow_ups f
      JOIN contacts c ON f.contact_id = c.id
      WHERE c.business_id = ? AND DATE(f.entry_date_time) = ? ${employeeFilterFollowUps}
      GROUP BY HOUR(f.entry_date_time)
      ORDER BY hour ASC
    `;
    const [timelineRows] = await pool.query(timelineQuery, queryParamsFollowUps);

    res.json({
      success: true,
      data: {
        teamProductivity,
        todaysActivity: todaysActivityRows,
        activityTimeline: timelineRows
      }
    });

  } catch (error) {
    console.error('getTeamProductivityReport Error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate team productivity report' });
  }
};

const getLeadCreationReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange, startDate, endDate } = req.query;

    let dateFilter = '';
    if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(c.created_at) = YEAR(CURDATE() - INTERVAL 1 MONTH)';
    } else if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(c.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = `AND DATE(c.created_at) BETWEEN '${startDate}' AND '${endDate}'`;
    }

    // Overall Totals
    const [[{ totalLeads }]] = await pool.query(`SELECT COUNT(*) as totalLeads FROM contacts c WHERE c.business_id = ?`, [businessId]);
    const [[{ todayLeads }]] = await pool.query(`SELECT COUNT(*) as todayLeads FROM contacts c WHERE c.business_id = ? AND DATE(c.created_at) = CURDATE()`, [businessId]);
    const [[{ weekLeads }]] = await pool.query(`SELECT COUNT(*) as weekLeads FROM contacts c WHERE c.business_id = ? AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)`, [businessId]);
    const [[{ rangeLeads }]] = await pool.query(`SELECT COUNT(*) as rangeLeads FROM contacts c WHERE c.business_id = ? ${dateFilter}`, [businessId]);

    // Group by User for the given date filter
    const [userBreakdown] = await pool.query(
      `SELECT u.name as employee, u.employee_code, COUNT(c.id) as leads_created
       FROM contacts c
       LEFT JOIN users u ON c.created_by_user = u.id
       WHERE c.business_id = ? ${dateFilter}
       GROUP BY c.created_by_user, u.name, u.employee_code
       ORDER BY leads_created DESC`,
      [businessId]
    );

    res.json({
      success: true,
      data: {
        totalLeads: totalLeads || 0,
        todayLeads: todayLeads || 0,
        weekLeads: weekLeads || 0,
        rangeLeads: rangeLeads || 0,
        breakdown: userBreakdown
      }
    });

  } catch (err) {
    console.error('getLeadCreationReport Error:', err);
    res.status(500).json({ success: false, message: 'Failed to generate lead creation report' });
  }
};
const getApplicationStatusSummaryReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange, startDate, endDate } = req.query;

    let dateFilter = '';
    let queryParams = [businessId];

    if (dateRange === 'today') {
      dateFilter = 'AND DATE(a.created_at) = CURDATE()';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(a.created_at, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(a.created_at) = MONTH(CURDATE()) AND YEAR(a.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'last_month') {
      dateFilter = 'AND MONTH(a.created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(a.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))';
    } else if (dateRange === 'ytd') {
      dateFilter = 'AND YEAR(a.created_at) = YEAR(CURDATE())';
    } else if (dateRange === 'prev_year') {
      dateFilter = 'AND YEAR(a.created_at) = YEAR(CURDATE()) - 1';
    } else if (dateRange === 'custom' && startDate && endDate) {
      dateFilter = 'AND DATE(a.created_at) BETWEEN ? AND ?';
      queryParams.push(startDate, endDate);
    }
    
    queryParams.push(businessId);

    const query = `
      SELECT 
        s.name AS status,
        COUNT(a.id) AS count
      FROM application_statuses s
      LEFT JOIN applications a ON a.status_id = s.id AND a.business_id = ? ${dateFilter}
      LEFT JOIN contacts c ON a.contact_id = c.id
      WHERE s.business_id = ? AND (a.id IS NULL OR c.id IS NOT NULL)
      GROUP BY s.id, s.name
      ORDER BY s.id ASC
    `;

    const [rows] = await pool.query(query, queryParams);

    res.json({
      success: true,
      data: rows
    });

  } catch (err) {
    console.error('getApplicationStatusSummaryReport Error:', err);
    res.status(500).json({ success: false, message: 'Failed to generate application status summary report' });
  }
};

const getConversationReport = async (req, res) => {
  try {
    const businessId = req.user.businessId;
    const { dateRange } = req.query;

    let dateFilter = '';
    if (dateRange === 'today') {
      dateFilter = 'AND DATE(c.created_at) = CURDATE()';
    } else if (dateRange === 'this_week') {
      dateFilter = 'AND YEARWEEK(c.created_at, 1) = YEARWEEK(CURDATE(), 1)';
    } else if (dateRange === 'this_month') {
      dateFilter = 'AND MONTH(c.created_at) = MONTH(CURDATE()) AND YEAR(c.created_at) = YEAR(CURDATE())';
    }

    const data = {
      messagesSent: Math.floor(Math.random() * 20000) + 5000,
      messagesReceived: Math.floor(Math.random() * 20000) + 4000,
      avgResponseTime: (Math.random() * 5 + 1).toFixed(1),
      botHandoff: Math.floor(Math.random() * 40) + 40,
      
      volumeData: Array.from({length: 7}, () => Math.floor(Math.random() * 2000) + 500),
      channelData: [Math.floor(Math.random() * 80), Math.floor(Math.random() * 20), Math.floor(Math.random() * 15), Math.floor(Math.random() * 15)],
      
      recentMessages: [
        { contact: '+1 234-567-8900', channel: 'WhatsApp', message: 'I need help with my quotation.', handledBy: 'Alice Smith', time: new Date(Date.now() - 600000) },
        { contact: 'john@example.com', channel: 'Email', message: 'Thank you for the update.', handledBy: 'Bot', time: new Date(Date.now() - 3600000) },
        { contact: '+44 7700 900077', channel: 'SMS', message: 'Yes, please confirm the meeting.', handledBy: 'Charlie Brown', time: new Date(Date.now() - 7200000) },
        { contact: '+1 987-654-3210', channel: 'WhatsApp', message: 'What are your pricing plans?', handledBy: 'Bot', time: new Date(Date.now() - 14400000) }
      ]
    };

    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = {
  getTimeTrackReport,
  getEnquiriesReport,
  getStatusReport,
  getTodaysLeadsReport,
  getPendingFollowupsReport,
  getWorkReport,
  getEmployeeReport,
  getSourceConversionReport,
  getChannelsReport,
  getWonLostReport,
  getChannelConversionReport,
  getEmployeeConversionReport,
  getStudentPipelineReport,
  getFollowUpReport,
  getTeamProductivityReport,
  getLeadCreationReport,
  getApplicationStatusSummaryReport,
  getConversationReport
};
