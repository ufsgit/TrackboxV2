const pool = require('../db/pool');
const { getAccessibleUserIds, buildUserScopeFilter } = require('../services/teamHierarchy.service');

// Strip garbled encoding artifacts (e.g. em-dash stored in latin1 column comes back as Î“Ã‡Ã¶)
// Heuristic: if >50% of chars are non-ASCII and string is â‰¤10 chars â†’ treat as garbage
const sanitizeRemark = (text) => {
  if (!text) return null;
  const t = text.trim();
  if (!t) return null;
  const nonAscii = (t.match(/[^\x00-\x7F]/g) || []).length;
  if (nonAscii > 0 && (nonAscii / t.length) > 0.5 && t.length <= 10) return null;
  return t;
};

const { parseFile, buildCSV } = require('../utils/csvParser');
const { v4: uuidv4 } = require('crypto');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const r2Service = require('../services/r2.service');

const normalizeDateOnly = (val) => {
  if (!val) return null;
  if (typeof val === 'string') {
    const trimmed = val.trim();
    const match = trimmed.match(/^(\d{4}-\d{2}-\d{2})/);
    if (match) return match[1];
  }
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, '0');
    const d = String(val.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  return null;
};

const paginate = (page, limit) => {
  const p = Math.max(1, parseInt(page) || 1);
  const l = Math.min(10000, parseInt(limit) || 1000);
  return { offset: (p - 1) * l, limit: l, page: p };
};

const getContacts = async (req, res) => {
  try {
    const { page, limit, tags, channel, search, status, agent, has_followup, has_applications, app_status, receipt_type, enquiry_for } = req.query;
    const { offset, limit: lim, page: p } = paginate(page, limit);
    const bizId = req.user.businessId;

    let where = 'WHERE c.business_id = ?';
    const params = [bizId];

    if (has_applications === '1' || has_applications === 'true') {
      where += ' AND EXISTS (SELECT 1 FROM applications a WHERE a.contact_id = c.id)';
    }

    if (app_status) {
      where += ` AND EXISTS (
        SELECT 1 FROM applications a 
        LEFT JOIN application_statuses s ON a.status_id = s.id 
        WHERE a.contact_id = c.id 
          AND (LOWER(TRIM(COALESCE(s.name, ''))) LIKE LOWER(CONCAT('%', ?, '%')) OR a.status_id = ?)
      )`;
      params.push(app_status.trim(), app_status.trim());
    }

    if (receipt_type) {
      where += ` AND EXISTS (
        SELECT 1 FROM receipts r
        LEFT JOIN receipt_types rt ON r.receipt_type_id = rt.id
        WHERE r.contact_id = c.id
          AND (
            LOWER(TRIM(COALESCE(r.receipt_type_name, ''))) LIKE LOWER(CONCAT('%', ?, '%'))
            OR LOWER(TRIM(COALESCE(rt.name, ''))) LIKE LOWER(CONCAT('%', ?, '%'))
          )
      )`;
      params.push(receipt_type.trim(), receipt_type.trim());
    }

    const accessibleUserIds = await getAccessibleUserIds(req.user, bizId);
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        where += ' AND 1 = 0 ';
      } else if (req.query.transferred_only === 'true') {
        const selfId = Number(req.user.userId || req.user.id);
        where += ` AND (JSON_CONTAINS(c.user_list, JSON_QUOTE(?)) OR JSON_CONTAINS(c.user_list, ?) OR c.created_by_user = ?) AND (c.assigned_to != ? OR c.assigned_to IS NULL)`;
        params.push(selfId.toString(), selfId.toString(), selfId, selfId);
      } else if (agent === 'unassigned') {
        where += ' AND (c.assigned_to IS NULL OR c.assigned_to = 0) ';
      } else if (agent) {
        const reqAgentId = Number(agent);
        if (accessibleUserIds.includes(reqAgentId)) {
          where += ' AND c.assigned_to = ? ';
          params.push(reqAgentId);
        } else {
          where += ' AND 1 = 0 ';
        }
      } else {
        where += ` AND c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')})`;
        params.push(...accessibleUserIds);
      }
    } else {
      if (req.query.transferred_only === 'true') {
        if (agent) {
          where += ` AND (JSON_CONTAINS(c.user_list, JSON_QUOTE(?)) OR JSON_CONTAINS(c.user_list, ?) OR c.created_by_user = ?) AND (c.assigned_to != ? OR c.assigned_to IS NULL)`;
          params.push(agent.toString(), agent, agent, agent);
        } else {
          where += ` AND (JSON_LENGTH(c.user_list) > 1 OR (c.created_by_user IS NOT NULL AND c.created_by_user != c.assigned_to))`;
        }
      } else if (agent === 'unassigned') {
        where += ' AND (c.assigned_to IS NULL OR c.assigned_to = 0)';
      } else if (agent) {
        where += ' AND c.assigned_to = ?';
        params.push(agent);
      }
    }
    if (channel) { where += ' AND c.channel_preference = ?'; params.push(channel); }
    const sLower = (status || '').trim().toLowerCase();
    const isNoFollowUpFilter = sLower === 'status is not follow up' || 
                               sLower === 'not follow up' || 
                               sLower === 'no follow up' || 
                               sLower === 'no_followup' || 
                               sLower === 'no date';

    if (has_followup === '1' || has_followup === 'true') {
      where += ' AND c.follow_up_date IS NOT NULL';
    }
    if (isNoFollowUpFilter) {
      where += ' AND c.follow_up_date IS NULL';
    } else if (status) {
      where += ' AND c.status_name = ?';
      params.push(status);
    }
    if (search) { where += ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)'; params.push(`%${search}%`, `%${search}%`, `%${search}%`); }
    if (tags) { where += ' AND JSON_CONTAINS(c.tags, ?)'; params.push(JSON.stringify(tags)); }
    if (enquiry_for) {
      where += ` AND (c.enquiry_for_id = ? OR EXISTS (SELECT 1 FROM enquiry_fors ef WHERE ef.id = c.enquiry_for_id AND LOWER(TRIM(ef.name)) = LOWER(TRIM(?))))`;
      params.push(enquiry_for, enquiry_for);
    }

    const [[{ total, with_followup, without_followup }]] = await pool.query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN c.follow_up_date IS NOT NULL THEN 1 END) as with_followup,
        COUNT(CASE WHEN c.follow_up_date IS NULL THEN 1 END) as without_followup
      FROM contacts c ${where}
    `, params);
    const [rows] = await pool.query(`
      SELECT c.*, u.name as assigned_employee_name,
        e.name as enquiry_for_name,
        (SELECT remarks FROM follow_ups WHERE contact_id = c.id ORDER BY follow_up_id DESC LIMIT 1) as latest_remark
      FROM contacts c 
      LEFT JOIN users u ON c.assigned_to = u.id
      LEFT JOIN enquiry_fors e ON c.enquiry_for_id = e.id
      ${where} 
      ORDER BY c.created_at DESC, c.id DESC 
      LIMIT ? OFFSET ?
    `, [...params, lim, offset]);

    let baseWhere = 'WHERE c.business_id = ?';
    const baseParams = [bizId];
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        baseWhere += ' AND 1 = 0 ';
      } else {
        baseWhere += ` AND c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')})`;
        baseParams.push(...accessibleUserIds);
      }
    }
    const [[{ overall_total }]] = await pool.query(
      `SELECT COUNT(*) as overall_total FROM contacts c ${baseWhere}`,
      baseParams
    );

    res.json({ success: true, data: rows.map(r => ({ ...r, latest_remark: sanitizeRemark(r.latest_remark) })), total, overall_total: overall_total || total, with_followup, without_followup, page: p, limit: lim, message: 'OK' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const getContact = async (req, res) => {
  try {
    let q = `
      SELECT c.*,
             COALESCE(u.name, 'Unassigned') as assigned_employee_name,
             (SELECT remarks FROM follow_ups WHERE contact_id = c.id ORDER BY follow_up_id DESC LIMIT 1) as latest_remark,
             (SELECT follow_up_date FROM follow_ups WHERE contact_id = c.id ORDER BY follow_up_id DESC LIMIT 1) as latest_follow_up_date
      FROM contacts c
      LEFT JOIN users u ON c.assigned_to = u.id
      WHERE c.id = ? AND c.business_id = ?
    `;
    const params = [req.params.id, req.user.businessId];
    const accessibleUserIds = await getAccessibleUserIds(req.user, req.user.businessId);
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        q += ' AND 1 = 0 ';
      } else {
        q += ` AND (c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')}) OR c.created_by_user IN (${accessibleUserIds.map(() => '?').join(',')}) OR c.assigned_to IS NULL OR c.assigned_to = 0)`;
        params.push(...accessibleUserIds, ...accessibleUserIds);
      }
    }
    const [rows] = await pool.query(q, params);
    if (!rows.length) return res.status(404).json({ success: false, message: 'Not found', data: null });
    const contact = rows[0];

    const fDate = contact.follow_up_date || contact.latest_follow_up_date;
    if (fDate) {
      try {
        const d = new Date(fDate);
        const now = new Date();
        d.setHours(0,0,0,0);
        now.setHours(0,0,0,0);
        if (d.getTime() < now.getTime()) contact.followup_status = 'Overdue';
        else if (d.getTime() === now.getTime()) contact.followup_status = 'Due Today';
        else contact.followup_status = 'Upcoming';
      } catch(e) {}
    }

    // Fetch allowed categories for the user
    let allowedCategories = null;
    if (req.user.role !== 'superadmin' && req.user.role !== 'admin') {
      const [uRows] = await pool.query('SELECT allowed_custom_field_categories FROM users WHERE id = ?', [req.user.userId]);
      if (uRows.length && uRows[0].allowed_custom_field_categories) {
        allowedCategories = typeof uRows[0].allowed_custom_field_categories === 'string' 
          ? JSON.parse(uRows[0].allowed_custom_field_categories) 
          : uRows[0].allowed_custom_field_categories;
      }
    }

    // Fetch custom field values with field metadata
    const [customValues] = await pool.query(
      `SELECT lf.id as field_id, lf.category_id, lf.label, lf.field_key, lf.field_type, lf.options, lf.is_required, lf.display_order,
              ccv.value
       FROM lead_fields lf
       LEFT JOIN contact_custom_values ccv ON ccv.field_id = lf.id AND ccv.contact_id = ?
       WHERE lf.business_id = ?
       ORDER BY lf.display_order ASC, lf.id ASC`,
      [req.params.id, req.user.businessId]
    );

    let mappedValues = customValues.map(f => ({
      ...f,
      options: typeof f.options === 'string' ? JSON.parse(f.options || '[]') : (f.options || [])
    }));

    if (allowedCategories !== null && Array.isArray(allowedCategories)) {
      const allowedCategoriesStr = allowedCategories.map(c => String(c));
      mappedValues = mappedValues.filter(f => allowedCategoriesStr.includes(String(f.category_id)) || f.category_id === null);
    }

    contact.custom_fields = mappedValues;

    res.json({ success: true, data: contact, message: 'OK' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const createContact = async (reqOrData, res) => {
  const isHttp = Boolean(res && typeof res.status === 'function');
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const data = isHttp ? (reqOrData.body || {}) : (reqOrData || {});
    let { 
      name, phone, email, tags, channel_preference, assigned_to, address, 
      custom_field_values, status, remark, follow_up_date, enquiry_for_id, 
      branch_id, branch_name, department_id, department_name, 
      status_id, status_name, country_code,
      opted_in, opt_in_date, opt_out_date, opt_in_source, has_unread_wa,
      priority, probability_id, loss_reason
    } = data;

    const bizId = isHttp ? (reqOrData.user?.businessId || 1) : (data.business_id || 1);
    const actingUserId = isHttp ? reqOrData.user?.userId : (assigned_to || data.created_by_user || null);

    if (phone) {
      // 1. Remove all spaces automatically
      phone = String(phone).replace(/\s+/g, '').trim();

      // Normalize country code (default to India +91)
      country_code = country_code ? String(country_code).trim() : '+91';
      if (!country_code.startsWith('+')) country_code = '+' + country_code;

      // If user pasted a phone that starts with '+' or dial code, extract country_code if matches
      if (phone.startsWith('+')) {
        if (phone.startsWith(country_code)) {
          phone = phone.slice(country_code.length);
        } else {
          const dialMatch = phone.match(/^\+(\d{1,4})/);
          if (dialMatch) {
            const [matchedRows] = await conn.query('SELECT country_code FROM country_codes WHERE country_code = ? LIMIT 1', ['+' + dialMatch[1]]);
            if (matchedRows.length > 0) {
              country_code = '+' + dialMatch[1];
              phone = phone.slice(country_code.length);
            }
          }
        }
      }

      // If India (+91) and starts with '0' trunk prefix (e.g. 09876543210), strip the leading 0
      if (country_code === '+91' && phone.startsWith('0') && phone.length === 11) {
        phone = phone.slice(1);
      }

      const numericPhone = phone.replace(/\D/g, '');

      // Explicit Validation
      if (country_code === '+91') {
        if (numericPhone.length === 9) {
          await conn.rollback();
          conn.release();
          if (isHttp) {
            return res.status(400).json({ 
              success: false, 
              message: 'Phone number contains only 9 digits. A valid 10-digit mobile number is required for India (+91).', 
              data: null 
            });
          }
          throw new Error('Phone number contains only 9 digits. A valid 10-digit mobile number is required for India (+91).');
        }
        if (numericPhone.length !== 10) {
          await conn.rollback();
          conn.release();
          if (isHttp) {
            return res.status(400).json({ 
              success: false, 
              message: `Phone number must be exactly 10 digits for India (+91). Entered ${numericPhone.length} digits.`, 
              data: null 
            });
          }
          throw new Error(`Phone number must be exactly 10 digits for India (+91). Entered ${numericPhone.length} digits.`);
        }
      } else {
        if (numericPhone.length < 7 || numericPhone.length > 15) {
          await conn.rollback();
          conn.release();
          if (isHttp) {
            return res.status(400).json({ 
              success: false, 
              message: `Phone number is invalid for country code ${country_code}. Must be between 7 and 15 digits.`, 
              data: null 
            });
          }
          throw new Error(`Phone number is invalid for country code ${country_code}. Must be between 7 and 15 digits.`);
        }
      }

      phone = `${country_code}${numericPhone}`;

      // Check for duplicate by last 10 digits
      const last10 = numericPhone.slice(-10);
      const dupQuery = `
        SELECT c.id, u.name as agent_name 
        FROM contacts c 
        LEFT JOIN users u ON c.assigned_to = u.id 
        WHERE c.business_id = ? AND c.phone LIKE ? LIMIT 1
      `;
      const [dupRows] = await conn.query(dupQuery, [bizId, `%${last10}`]);
      if (dupRows.length > 0) {
        await conn.rollback();
        conn.release();
        const agentName = dupRows[0].agent_name || 'Unassigned';
        if (isHttp) {
          return res.status(409).json({ 
            success: false, 
            message: `The contact already exists. Assigned to: ${agentName}`, 
            data: null 
          });
        }
        const [existing] = await pool.query('SELECT * FROM contacts WHERE id = ?', [dupRows[0].id]);
        return existing[0];
      }
    }

    if ((!assigned_to || !branch_id || !department_id) && actingUserId) {
      const query = `
        SELECT u.branch_id, b.name as branch_name, u.department_id, d.name as department_name 
        FROM users u 
        LEFT JOIN branches b ON u.branch_id = b.id 
        LEFT JOIN departments d ON u.department_id = d.id 
        WHERE u.id = ?
      `;
      const [uRows] = await conn.query(query, [actingUserId]);
      if (uRows.length > 0) {
        if (!assigned_to) assigned_to = actingUserId;
        if (!branch_id) { 
          branch_id = uRows[0].branch_id; 
          branch_name = uRows[0].branch_name; 
        }
        if (!department_id) { 
          department_id = uRows[0].department_id; 
          department_name = uRows[0].department_name; 
        }
      }
    }

    let assignTo = assigned_to || null;
    if (isHttp && reqOrData.user?.role === 'agent') {
      assignTo = reqOrData.user.userId;
    }
    let userList = [];
    if (actingUserId && assignTo && Number(actingUserId) !== Number(assignTo)) {
      userList = [Number(actingUserId), Number(assignTo)];
    } else if (assignTo) {
      userList = [Number(assignTo)];
    }
    
    let formattedFollowUpDate = null;
    if (follow_up_date) {
      formattedFollowUpDate = normalizeDateOnly(follow_up_date);
    }

    let current_sale_status = 0;
    let sale_won = 0, sale_lost = 0;
    let sale_won_date = null, sale_lost_date = null;
    let sale_won_by = null, sale_lost_by = null;

    if (status_id) {
      const [statusRows] = await conn.query('SELECT type FROM statuses WHERE id = ?', [status_id]);
      if (statusRows.length > 0) {
        if (statusRows[0].type === 'sale') {
          current_sale_status = 1;
          sale_won = 1;
          sale_won_date = new Date();
          sale_won_by = assignTo;
        }
        else if (statusRows[0].type === 'sale_lost') {
          current_sale_status = 2;
          sale_lost = 1;
          sale_lost_date = new Date();
          sale_lost_by = assignTo;
        }
      }
    }

    const [result] = await conn.query(
      `INSERT INTO contacts (
        business_id, name, phone, country_code, email, tags, 
        opted_in, opt_in_date, opt_out_date, opt_in_source, channel_preference, has_unread_wa,
        assigned_to, address, enquiry_for_id, loss_reason, 
        branch_id, branch_name, department_id, department_name, 
        status_id, status_name, follow_up_date, follow_up,
        current_sale_status, sale_won, sale_won_date, sale_won_by, 
        sale_lost, sale_lost_date, sale_lost_by, 
        created_by_user, user_list, priority, probability_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        bizId, name, phone, country_code || '+91', email || null, JSON.stringify(tags || []),
        opted_in !== undefined ? (opted_in ? 1 : 0) : 0,
        opt_in_date || null, opt_out_date || null, opt_in_source || 'manual', channel_preference || 'whatsapp', has_unread_wa ? 1 : 0,
        assignTo, address || null, enquiry_for_id || null, loss_reason || null,
        branch_id || null, branch_name || null, department_id || null, department_name || null,
        status_id || null, status_name || null, formattedFollowUpDate, formattedFollowUpDate ? 1 : 0,
        current_sale_status, sale_won, sale_won_date, sale_won_by,
        sale_lost, sale_lost_date, sale_lost_by,
        actingUserId, JSON.stringify(userList), priority || null, probability_id || null
      ]
    );
    const contactId = result.insertId;

    // Fetch by_user_name and to_user_name
    let byUserName = null;
    let toUserName = null;
    if (actingUserId) {
      const [u] = await conn.query('SELECT name FROM users WHERE id = ?', [actingUserId]);
      if (u.length) byUserName = u[0].name;
    }
    if (assignTo) {
      const [tu] = await conn.query('SELECT name FROM users WHERE id = ?', [assignTo]);
      if (tu.length) toUserName = tu[0].name;
    }

    // Save initial follow up
    await conn.query(
      'INSERT INTO follow_ups (contact_id, contact_name, follow_up_date, by_user_id, by_user_name, to_user_id, to_user_name, status_id, status_name, branch_id, branch_name, department_id, department_name, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [contactId, name, formattedFollowUpDate, actingUserId, byUserName, assignTo, toUserName, status_id || null, status_name || null, branch_id || null, branch_name || null, department_id || null, department_name || null, remark || 'Contact created']
    );

    // Save custom field values
    if (custom_field_values && typeof custom_field_values === 'object') {
      for (const [fieldId, value] of Object.entries(custom_field_values)) {
        if (value !== undefined && value !== null && value !== '') {
          await conn.query(
            'INSERT INTO contact_custom_values (contact_id, business_id, field_id, value) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE value=VALUES(value)',
            [contactId, bizId, fieldId, String(value)]
          );
        }
      }
    }

    await conn.commit();

    const [rows] = await pool.query('SELECT * FROM contacts WHERE id = ?', [contactId]);
    
    if (assignTo) {
      const io = isHttp && reqOrData.app ? reqOrData.app.get('io') : null;
      await pool.query(
        `INSERT INTO notifications (business_id, user_id, type, title, message, reference_id)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [bizId, assignTo, 'assignment', 'New Contact Assigned', `You have been assigned a new contact: ${rows[0].name || rows[0].phone || 'Unknown'}`, contactId]
      );
      if (io) {
        io.to(`biz_${bizId}`).emit('contact_assigned', { contact: rows[0], assigned_to: assignTo });
        io.emit('contact_assigned', { contact: rows[0], assigned_to: assignTo });
      }
    }

    if (isHttp) {
      return res.status(201).json({ success: true, data: rows[0], message: 'Contact created' });
    }
    return rows[0];
  } catch (err) {
    if (conn) await conn.rollback();
    console.log('error from contacts', err);
    if (isHttp) {
      return res.status(500).json({ success: false, message: err.message, data: null });
    }
    throw err;
  } finally {
    if (conn) conn.release();
  }
};

const updateContact = async (req, res) => {
  let conn;
  try {
    conn = await pool.getConnection();
    await conn.beginTransaction();

    const bizId = req.user.businessId;
    const contactId = req.params.id;
    const userId = req.user.userId;
    const { custom_field_values, ...updateFields } = req.body;

    const [existingRows] = await conn.query('SELECT * FROM contacts WHERE id = ? AND business_id = ?', [contactId, bizId]);
    if (!existingRows.length) {
      await conn.rollback();
      conn.release();
      return res.status(404).json({ success: false, message: 'Not found', data: null });
    }
    const oldContact = existingRows[0];

    // Verify user has access to update this contact based on team hierarchy, user list, or assignment
    const accessibleUserIds = await getAccessibleUserIds(req.user, bizId);
    if (accessibleUserIds !== null) {
      const assignedId = oldContact.assigned_to != null ? Number(oldContact.assigned_to) : null;
      const creatorId = oldContact.created_by_user != null ? Number(oldContact.created_by_user) : null;
      const currentUserId = Number(userId);

      let userListIds = [];
      if (oldContact.user_list) {
        try {
          const parsed = typeof oldContact.user_list === 'string' ? JSON.parse(oldContact.user_list) : oldContact.user_list;
          if (Array.isArray(parsed)) {
            userListIds = parsed.map(x => Number(x));
          }
        } catch (e) {}
      }

      const isAssignedToAccessible = assignedId !== null && accessibleUserIds.includes(assignedId);
      const isCreatedByAccessible = creatorId !== null && accessibleUserIds.includes(creatorId);
      const isUserInList = userListIds.includes(currentUserId);
      const isUnassigned = assignedId === null || assignedId === 0;

      if (!isAssignedToAccessible && !isCreatedByAccessible && !isUserInList && !isUnassigned) {
        await conn.rollback();
        conn.release();
        return res.status(403).json({ success: false, message: 'You do not have permission to edit this contact.', data: null });
      }
    }

    // Phone validation and duplicate check
    if (updateFields.phone) {
      let rawPhone = String(updateFields.phone).replace(/\s+/g, '').trim();
      let cCode = updateFields.country_code ? String(updateFields.country_code).trim() : (oldContact.country_code || '+91');
      if (!cCode.startsWith('+')) cCode = '+' + cCode;

      if (rawPhone.startsWith('+')) {
        if (rawPhone.startsWith(cCode)) {
          rawPhone = rawPhone.slice(cCode.length);
        } else {
          const dialMatch = rawPhone.match(/^\+(\d{1,4})/);
          if (dialMatch) {
            const [matchedRows] = await conn.query('SELECT country_code FROM country_codes WHERE country_code = ? LIMIT 1', ['+' + dialMatch[1]]);
            if (matchedRows.length > 0) {
              cCode = '+' + dialMatch[1];
              rawPhone = rawPhone.slice(cCode.length);
            }
          }
        }
      }

      if (cCode === '+91' && rawPhone.startsWith('0') && rawPhone.length === 11) {
        rawPhone = rawPhone.slice(1);
      }

      const numericPhone = rawPhone.replace(/\D/g, '');

      if (cCode === '+91') {
        if (numericPhone.length === 9) {
          await conn.rollback();
          conn.release();
          return res.status(400).json({ 
            success: false, 
            message: 'Phone number contains only 9 digits. A valid 10-digit mobile number is required for India (+91).', 
            data: null 
          });
        }
        if (numericPhone.length !== 10) {
          await conn.rollback();
          conn.release();
          return res.status(400).json({ 
            success: false, 
            message: `Phone number must be exactly 10 digits for India (+91). Entered ${numericPhone.length} digits.`, 
            data: null 
          });
        }
      } else {
        if (numericPhone.length < 7 || numericPhone.length > 15) {
          await conn.rollback();
          conn.release();
          return res.status(400).json({ 
            success: false, 
            message: `Phone number is invalid for country code ${cCode}. Must be between 7 and 15 digits.`, 
            data: null 
          });
        }
      }

      updateFields.phone = `${cCode}${numericPhone}`;
      updateFields.country_code = cCode;

      const last10 = numericPhone.slice(-10);
      const dupQuery = `
        SELECT c.id, u.name as agent_name 
        FROM contacts c 
        LEFT JOIN users u ON c.assigned_to = u.id 
        WHERE c.business_id = ? AND c.phone LIKE ? AND c.id != ? LIMIT 1
      `;
      const [dupRows] = await conn.query(dupQuery, [bizId, `%${last10}`, contactId]);
      if (dupRows.length > 0) {
        await conn.rollback();
        conn.release();
        const agentName = dupRows[0].agent_name || 'Unassigned';
        return res.status(409).json({ 
          success: false, 
          message: `The contact already exists. Assigned to: ${agentName}`, 
          data: null 
        });
      }
    }
    // Format follow_up_date if provided; convert empty string to null
    if (updateFields.follow_up_date !== undefined) {
      if (updateFields.follow_up_date && updateFields.follow_up_date !== '') {
        updateFields.follow_up_date = normalizeDateOnly(updateFields.follow_up_date);
      } else {
        updateFields.follow_up_date = null;
      }
    }

    // Determine whether this update is specifically a follow-up action
    let shouldLogFollowUp = false;
    if (updateFields.is_follow_up !== undefined) {
      shouldLogFollowUp = Boolean(updateFields.is_follow_up);
    } else {
      // If is_follow_up is not explicitly provided:
      // Lead detail edits (name, phone, email, address, enquiry_for_id, channel_preference, tags, custom fields) MUST NOT log to follow_ups
      const isLeadDetailEdit = Boolean(
        updateFields.name || updateFields.phone || updateFields.email || 
        updateFields.address || updateFields.channel_preference || 
        updateFields.enquiry_for_id || custom_field_values
      );

      const hasRemarks = Boolean(
        (updateFields.remarks && String(updateFields.remarks).trim()) || 
        (updateFields.remark && String(updateFields.remark).trim())
      );
      const statusChanged = (updateFields.status_id !== undefined && String(updateFields.status_id) !== String(oldContact.status_id || '')) ||
                            (updateFields.status_name !== undefined && updateFields.status_name !== (oldContact.status_name || ''));
      const assigneeChanged = (updateFields.assigned_to !== undefined && String(updateFields.assigned_to) !== String(oldContact.assigned_to || ''));
      const followUpDateChanged = (updateFields.follow_up_date !== undefined && updateFields.follow_up_date !== oldContact.follow_up_date);

      if (!isLeadDetailEdit && (hasRemarks || statusChanged || assigneeChanged || followUpDateChanged)) {
        shouldLogFollowUp = true;
      }
    }

    // Step 1: Log to follow_ups ONLY if this is specifically a follow-up action
    if (shouldLogFollowUp) {
      let byUserName = null;
      let toUserName = null;
      const toUserId = updateFields.assigned_to !== undefined ? (updateFields.assigned_to || null) : oldContact.assigned_to;
      if (userId) {
        const [u] = await conn.query('SELECT name FROM users WHERE id = ?', [userId]);
        if (u.length) byUserName = u[0].name;
      }
      if (toUserId) {
        const [tu] = await conn.query('SELECT name FROM users WHERE id = ?', [toUserId]);
        if (tu.length) toUserName = tu[0].name;
      }

      await conn.query(
        'INSERT INTO follow_ups (contact_id, contact_name, follow_up_date, by_user_id, by_user_name, to_user_id, to_user_name, status_id, status_name, branch_id, branch_name, department_id, department_name, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          contactId, 
          updateFields.name || oldContact.name, 
          (updateFields.follow_up_date !== undefined ? updateFields.follow_up_date : oldContact.follow_up_date) || null, 
          userId, 
          byUserName,
          toUserId, 
          toUserName,
          updateFields.status_id !== undefined ? updateFields.status_id : oldContact.status_id, 
          updateFields.status_name !== undefined ? updateFields.status_name : oldContact.status_name, 
          updateFields.branch_id !== undefined ? updateFields.branch_id : oldContact.branch_id, 
          updateFields.branch_name !== undefined ? updateFields.branch_name : oldContact.branch_name, 
          updateFields.department_id !== undefined ? updateFields.department_id : oldContact.department_id, 
          updateFields.department_name !== undefined ? updateFields.department_name : oldContact.department_name, 
          updateFields.remarks !== undefined ? updateFields.remarks : (updateFields.remark || '')
        ]
      );
    }

    // Step 2: UPDATE contacts
    let updates = [];
    let params = [];

    const allowedFields = ['name', 'phone', 'email', 'tags', 'channel_preference', 'address', 'follow_up_date', 'enquiry_for_id', 'branch_id', 'branch_name', 'department_id', 'department_name', 'status_id', 'status_name', 'sale_won', 'sale_lost', 'loss_reason'];
    
    for (const key of allowedFields) {
      if (updateFields[key] !== undefined) {
        updates.push(`${key} = ?`);
        params.push(key === 'tags' ? JSON.stringify(updateFields[key] || []) : (updateFields[key] || null));
      }
    }

    if (updateFields.status_id !== undefined) {
      let saleStatus = 0;
      if (updateFields.status_id) {
        const [statusRows] = await conn.query('SELECT type FROM statuses WHERE id = ?', [updateFields.status_id]);
        if (statusRows.length > 0) {
          if (statusRows[0].type === 'sale') saleStatus = 1;
          else if (statusRows[0].type === 'sale_lost') saleStatus = 2;
        }
      }
      updates.push('current_sale_status = ?');
      params.push(saleStatus);

      let finalAssignedTo = updateFields.assigned_to !== undefined ? updateFields.assigned_to : oldContact.assigned_to;
      if (saleStatus === 1) {
        updates.push('sale_won = 1, sale_won_date = ?, sale_won_by = ?, sale_lost = 0, sale_lost_date = NULL, sale_lost_by = NULL');
        params.push(new Date(), finalAssignedTo);
      } else if (saleStatus === 2) {
        updates.push('sale_lost = 1, sale_lost_date = ?, sale_lost_by = ?, sale_won = 0, sale_won_date = NULL, sale_won_by = NULL');
        params.push(new Date(), finalAssignedTo);
      } else {
        updates.push('sale_won = 0, sale_won_date = NULL, sale_won_by = NULL, sale_lost = 0, sale_lost_date = NULL, sale_lost_by = NULL');
      }
    }

    if (updateFields.assigned_to !== undefined) {
      updates.push('assigned_to = ?');
      params.push(updateFields.assigned_to || null);

      if (updateFields.assigned_to) {
        let currentList = oldContact.user_list ? (typeof oldContact.user_list === 'string' ? JSON.parse(oldContact.user_list) : oldContact.user_list) : [];
        if (oldContact.assigned_to && !currentList.includes(oldContact.assigned_to) && !currentList.includes(String(oldContact.assigned_to)) && !currentList.includes(Number(oldContact.assigned_to))) {
          currentList.push(oldContact.assigned_to);
        }
        if (!currentList.includes(updateFields.assigned_to) && !currentList.includes(String(updateFields.assigned_to)) && !currentList.includes(Number(updateFields.assigned_to))) {
          currentList.push(updateFields.assigned_to);
        }
        updates.push('user_list = ?');
        params.push(JSON.stringify(currentList));
      }
    }

    if (updateFields.follow_up_date !== undefined) {
      updates.push('follow_up = ?');
      params.push(updateFields.follow_up_date ? 1 : 0);
    }

    if (updates.length > 0) {
      if (shouldLogFollowUp) {
          updates.push('follow_up_count = follow_up_count + 1');
      }

      let query = `UPDATE contacts SET ${updates.join(', ')} WHERE id = ? AND business_id = ?`;
      params.push(contactId, bizId);
      await conn.query(query, params);
    }

    const formatValue = (val) => {
      if (val instanceof Date) return normalizeDateOnly(val);
      return val ? String(val) : null;
    };
    const logHistory = async (field, oldVal, newVal) => {
      const formattedOld = formatValue(oldVal);
      const formattedNew = formatValue(newVal);
      if (formattedOld !== formattedNew) {
        await conn.query(
          'INSERT INTO contact_history (contact_id, business_id, user_id, field_name, old_value, new_value) VALUES (?, ?, ?, ?, ?, ?)',
          [contactId, bizId, userId, field, formattedOld, formattedNew]
        );
      }
    };

    if (updateFields.status !== undefined) await logHistory('status', oldContact.status, updateFields.status);
    if (updateFields.remark !== undefined) await logHistory('remark', oldContact.remark, updateFields.remark);
    if (updateFields.follow_up_date !== undefined) await logHistory('follow_up_date', oldContact.follow_up_date, updateFields.follow_up_date);

    if (custom_field_values && typeof custom_field_values === 'object') {
      for (const [fieldId, value] of Object.entries(custom_field_values)) {
        if (value !== undefined && value !== null && value !== '') {
          await conn.query(
            'INSERT INTO contact_custom_values (contact_id, business_id, field_id, value) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE value=VALUES(value)',
            [contactId, bizId, fieldId, String(value)]
          );
        } else {
          await conn.query('DELETE FROM contact_custom_values WHERE contact_id=? AND field_id=?', [contactId, fieldId]);
        }
      }
    }

    await conn.commit();

    const [rows] = await pool.query('SELECT * FROM contacts WHERE id = ?', [contactId]);
    if (updateFields.assigned_to !== undefined && updateFields.assigned_to !== null) {
      const io = req.app && typeof req.app.get === 'function' ? req.app.get('io') : null;
      await pool.query(
        `INSERT INTO notifications (business_id, user_id, type, title, message, reference_id)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [bizId, updateFields.assigned_to, 'assignment', 'Contact Reassigned', `A contact has been assigned to you: ${rows[0].name || rows[0].phone || 'Unknown'}`, contactId]
      );
      if (io) {
        io.to(`biz_${bizId}`).emit('contact_assigned', { contact: rows[0], assigned_to: updateFields.assigned_to });
        io.emit('contact_assigned', { contact: rows[0], assigned_to: updateFields.assigned_to });
      }
    }

    res.json({ success: true, data: rows[0], message: 'Updated' });
  } catch (err) {
    if (conn) await conn.rollback();
    res.status(500).json({ success: false, message: err.message, data: null });
  } finally {
    if (conn) conn.release();
  }
};

const deleteContact = async (req, res) => {
  let conn;
  try {
    const contactId = req.params.id;
    const bizId = req.user.businessId;

    let checkQuery = 'SELECT id FROM contacts WHERE id = ? AND business_id = ?';
    const params = [contactId, bizId];
    const accessibleUserIds = await getAccessibleUserIds(req.user, bizId);
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        checkQuery += ' AND 1 = 0 ';
      } else {
        checkQuery += ` AND (assigned_to IN (${accessibleUserIds.map(() => '?').join(',')}) OR created_by_user IN (${accessibleUserIds.map(() => '?').join(',')}) OR assigned_to IS NULL OR assigned_to = 0)`;
        params.push(...accessibleUserIds, ...accessibleUserIds);
      }
    }
    const [check] = await pool.query(checkQuery, params);
    if (!check.length) {
      return res.status(404).json({ success: false, message: 'Not found or access denied', data: null });
    }

    conn = await pool.getConnection();
    await conn.beginTransaction();

    // Helper to safely execute delete on related tables (ignores table if it doesn't exist)
    const safeDelete = async (query, args = [contactId]) => {
      try {
        await conn.query(query, args);
      } catch (e) {
        // Table might not exist or ignore minor non-fatal errors
      }
    };

    // 1. Delete associated conversations & messages
    const [convos] = await conn.query('SELECT id FROM conversations WHERE contact_id = ?', [contactId]);
    if (convos.length > 0) {
      const convoIds = convos.map(c => c.id);
      await conn.query('DELETE FROM messages WHERE conversation_id IN (?)', [convoIds]);
      await conn.query('DELETE FROM conversations WHERE contact_id = ?', [contactId]);
    }

    // 2. Delete all related foreign key rows
    await safeDelete('DELETE FROM chatbot_sessions WHERE contact_id = ?');
    await safeDelete('DELETE FROM follow_ups WHERE contact_id = ?');
    await safeDelete('DELETE FROM contact_history WHERE contact_id = ?');
    await safeDelete('DELETE FROM contact_custom_values WHERE contact_id = ?');
    await safeDelete('DELETE FROM applications WHERE contact_id = ?');
    await safeDelete('DELETE FROM leads WHERE contact_id = ?');
    await safeDelete('DELETE FROM contact_documents WHERE contact_id = ?');
    await safeDelete('DELETE FROM drip_enrollments WHERE contact_id = ?');
    await safeDelete('DELETE FROM broadcast_logs WHERE contact_id = ?');
    await safeDelete('DELETE FROM orders WHERE contact_id = ?');

    // 3. Delete contact row
    await conn.query('DELETE FROM contacts WHERE id = ?', [contactId]);

    await conn.commit();
    res.json({ success: true, data: null, message: 'Deleted successfully' });
  } catch (err) {
    if (conn) await conn.rollback();
    res.status(500).json({ success: false, message: err.message, data: null });
  } finally {
    if (conn) conn.release();
  }
};

const importContacts = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded', data: null });
    const rows = await parseFile(req.file.path);
    const bizId = req.user.businessId;
    let imported = 0;
    
    // Parse assignments if provided
    let assignments = [];
    if (req.body.assignments) {
      try {
        assignments = JSON.parse(req.body.assignments);
      } catch (e) {
        console.error('Failed to parse assignments:', e);
      }
    }
    
    // Global Settings
    const globalBranchId = req.body.branch_id || null;
    const globalDepartmentId = req.body.department_id || null;
    const globalStatusId = req.body.status_id || null;
    const globalEnquirySourceId = req.body.enquiry_source_id || null;

    const [statusRows] = await conn.query('SELECT id, name, type FROM statuses');
    const statusMap = new Map();
    for (const s of statusRows) {
      statusMap.set(String(s.id), s);
      statusMap.set(s.name.toLowerCase().trim(), s);
    }
    const globalStatusObj = globalStatusId && statusMap.has(String(globalStatusId)) ? statusMap.get(String(globalStatusId)) : null;
    
    let globalBranchName = null;
    let globalDepartmentName = null;
    
    if (globalBranchId) {
      const [b] = await conn.query('SELECT name FROM branches WHERE id = ?', [globalBranchId]);
      if (b.length) globalBranchName = b[0].name;
    }
    if (globalDepartmentId) {
      const [d] = await conn.query('SELECT name FROM departments WHERE id = ?', [globalDepartmentId]);
      if (d.length) globalDepartmentName = d[0].name;
    }

    // Get uploader's info as fallback
    const [uploaderRows] = await conn.query(
      `SELECT u.branch_id, b.name as branch_name, u.department_id, d.name as department_name 
       FROM users u 
       LEFT JOIN branches b ON u.branch_id = b.id 
       LEFT JOIN departments d ON u.department_id = d.id 
       WHERE u.id = ?`,
      [req.user.userId]
    );
    const uploaderInfo = uploaderRows[0] || {};
    
    // Get info for all assigned users to avoid querying in the loop
    const userDetailsMap = {};
    if (assignments && assignments.length > 0) {
      const userIds = assignments.map(a => a.userId);
      const [uRows] = await conn.query(
        `SELECT u.id, u.branch_id, b.name as branch_name, u.department_id, d.name as department_name 
         FROM users u 
         LEFT JOIN branches b ON u.branch_id = b.id 
         LEFT JOIN departments d ON u.department_id = d.id 
         WHERE u.id IN (?)`,
        [userIds]
      );
      for (const r of uRows) {
        userDetailsMap[r.id] = r;
      }
    }
    
    await conn.beginTransaction();

    let currentUserAssignmentIndex = 0;
    let currentUserCount = 0;

    for (const row of rows) {
      // Normalize keys by converting to lowercase
      const normalizedRow = {};
      for (let key in row) {
        if (Object.prototype.hasOwnProperty.call(row, key)) {
          normalizedRow[key.toLowerCase().trim()] = row[key];
        }
      }
      
      const name = normalizedRow.name || '';
      const phone = normalizedRow.phone || normalizedRow.contact || '';
      const email = normalizedRow.email || '';
      const rawTags = normalizedRow.tags || '';
      const tags = rawTags ? JSON.stringify(rawTags.split('|').map(t => t.trim())) : '[]';
      const address = normalizedRow.address || null;
      
      if (!phone) continue; // Skip rows without phone

      // Distribution Logic
      let assignTo = req.user.userId; // Default to uploader
      let branch_id = globalBranchId || uploaderInfo.branch_id || null;
      let branch_name = globalBranchName || uploaderInfo.branch_name || null;
      let department_id = globalDepartmentId || uploaderInfo.department_id || null;
      let department_name = globalDepartmentName || uploaderInfo.department_name || null;

      if (assignments && assignments.length > 0 && currentUserAssignmentIndex < assignments.length) {
        const currentAssignment = assignments[currentUserAssignmentIndex];
        assignTo = currentAssignment.userId;
        
        // Only use agent's branch/dept if global wasn't provided
        const targetUserDetails = userDetailsMap[assignTo];
        if (targetUserDetails) {
          if (!globalBranchId) branch_id = targetUserDetails.branch_id;
          if (!globalBranchName) branch_name = targetUserDetails.branch_name;
          if (!globalDepartmentId) department_id = targetUserDetails.department_id;
          if (!globalDepartmentName) department_name = targetUserDetails.department_name;
        }
        
        currentUserCount++;
        if (currentUserCount >= currentAssignment.count) {
          currentUserAssignmentIndex++;
          currentUserCount = 0;
        }
      }

      // Check status: skip entire row if a new/unrecognized status is found
      const rowStatus = normalizedRow.status || normalizedRow['lead status'] || normalizedRow['current status'] || normalizedRow.stage;
      let sObj = globalStatusObj;
      if (rowStatus && String(rowStatus).trim()) {
        const cleanRowStatus = String(rowStatus).toLowerCase().trim();
        if (!statusMap.has(cleanRowStatus)) {
          continue; // Skip row if status does not exist in the system
        }
        sObj = statusMap.get(cleanRowStatus);
      } else if (globalStatusId && !globalStatusObj) {
        continue;
      }

      const userList = [assignTo];
      const enquiryForId = globalEnquirySourceId || null;
      const statusId = sObj ? sObj.id : null;

      const [result] = await conn.query(
        `INSERT INTO contacts 
         (business_id, name, phone, email, tags, address, opt_in_source, assigned_to, branch_id, branch_name, department_id, department_name, user_list, enquiry_for_id, status_id) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) 
         ON DUPLICATE KEY UPDATE name=VALUES(name), tags=VALUES(tags), address=VALUES(address), assigned_to=VALUES(assigned_to), branch_id=VALUES(branch_id), branch_name=VALUES(branch_name), department_id=VALUES(department_id), department_name=VALUES(department_name), user_list=VALUES(user_list), enquiry_for_id=IFNULL(VALUES(enquiry_for_id), enquiry_for_id), status_id=IFNULL(VALUES(status_id), status_id)`,
        [bizId, name, phone, email, tags, address, 'import', assignTo, branch_id, branch_name, department_id, department_name, JSON.stringify(userList), enquiryForId, statusId]
      );
      
      // Check if it's a new insert or update by checking affectedRows.
      // If it's a new insert, let's create a follow_up entry.
      // 1 means inserted, 2 means updated
      if (result.affectedRows === 1) {
        await conn.query(
          'INSERT INTO follow_ups (contact_id, contact_name, by_user_id, to_user_id, branch_id, branch_name, department_id, department_name, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [result.insertId, name, req.user.userId, assignTo, branch_id, branch_name, department_id, department_name, 'Contact imported']
        );
      }
      
      imported++;
    }
    
    await conn.commit();
    fs.unlinkSync(req.file.path);
    res.json({ success: true, data: { imported }, message: `${imported} contacts imported successfully` });
  } catch (err) {
    await conn.rollback();
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    res.status(500).json({ success: false, message: err.message, data: null });
  } finally {
    conn.release();
  }
};

const exportContacts = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT name, phone, email, opted_in, channel_preference, created_at FROM contacts WHERE business_id = ?', [req.user.businessId]);
    const csv = buildCSV(rows, ['name', 'phone', 'email', 'opted_in', 'channel_preference', 'created_at']);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=contacts.csv');
    res.send(csv);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const optIn = async (req, res) => {
  try {
    const { source } = req.body;
    await pool.query(
      'UPDATE contacts SET opted_in=1, opt_in_date=NOW(), opt_in_source=? WHERE id=? AND business_id=?',
      [source || 'manual', req.params.id, req.user.businessId]
    );
    res.json({ success: true, data: null, message: 'Opted in' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const optOut = async (req, res) => {
  try {
    await pool.query(
      'UPDATE contacts SET opted_in=0, opt_out_date=NOW() WHERE id=? AND business_id=?',
      [req.params.id, req.user.businessId]
    );
    res.json({ success: true, data: null, message: 'Opted out' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const createOptInLink = async (req, res) => {
  try {
    const { redirectUrl } = req.body;
    const token = crypto.randomBytes(16).toString('hex');
    await pool.query(
      'INSERT INTO opt_in_links (business_id, token, redirect_url) VALUES (?, ?, ?)',
      [req.user.businessId, token, redirectUrl || '']
    );
    const link = `${process.env.BASE_URL}/optin/${token}`;
    res.json({ success: true, data: { token, link }, message: 'Opt-in link created' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const handleOptInLink = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM opt_in_links WHERE token = ?', [req.params.token]);
    if (!rows.length) return res.status(404).send('Invalid link');
    const link = rows[0];
    const phone = req.query.phone;
    if (phone) {
      const [contacts] = await pool.query('SELECT id FROM contacts WHERE business_id=? AND phone=?', [link.business_id, phone]);
      if (contacts.length) {
        await pool.query('UPDATE contacts SET opted_in=1, opt_in_date=NOW(), opt_in_source=? WHERE id=?', ['link', contacts[0].id]);
      } else {
        await pool.query('INSERT INTO contacts (business_id, phone, opted_in, opt_in_date, opt_in_source) VALUES (?, ?, 1, NOW(), ?)', [link.business_id, phone, 'link']);
      }
    }
    if (link.redirect_url) return res.redirect(link.redirect_url);
    res.send('<html><body><h2>âœ… You have successfully opted in!</h2></body></html>');
  } catch (err) {
    res.status(500).send('Error processing opt-in');
  }
};

const getUniqueTags = async (req, res) => {
  try {
    const bizId = req.user.businessId;
    const [rows] = await pool.query('SELECT tags FROM contacts WHERE business_id = ? AND tags IS NOT NULL', [bizId]);
    const tags = new Set();
    rows.forEach(r => {
      let ct = r.tags;
      if (typeof ct === 'string') {
        try { ct = JSON.parse(ct); } catch (e) { ct = []; }
      }
      if (Array.isArray(ct)) {
        ct.forEach(t => {
          if (t && typeof t === 'string' && t.trim()) {
            tags.add(t.trim());
          }
        });
      }
    });
    res.json({ success: true, data: Array.from(tags), message: 'OK' });
  } catch (err) {
    console.error('[getUniqueTags] Error:', err.message);
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const getContactHistory = async (req, res) => {
  try {
    const contactId = req.params.id;
    const bizId = req.user.businessId;
    
    // Ensure user has access to contact
    let q = 'SELECT id FROM contacts WHERE id = ? AND business_id = ?';
    const params = [contactId, bizId];
    const accessibleUserIds = await getAccessibleUserIds(req.user, bizId);
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        q += ' AND 1 = 0 ';
      } else {
        q += ` AND (assigned_to IN (${accessibleUserIds.map(() => '?').join(',')}) OR created_by_user IN (${accessibleUserIds.map(() => '?').join(',')}) OR assigned_to IS NULL OR assigned_to = 0)`;
        params.push(...accessibleUserIds, ...accessibleUserIds);
      }
    }
    const [contacts] = await pool.query(q, params);
    console.log('[DEBUG] getContactHistory -> contactId:', contactId, 'bizId:', bizId, 'role:', req.user.role, 'userId:', req.user.userId, 'contacts:', contacts);
    if (!contacts.length) return res.status(404).json({ success: false, message: 'Contact not found or access denied', data: null });

    const [history] = await pool.query(`
      SELECT ch.*, u.name as changed_by_name 
      FROM contact_history ch 
      LEFT JOIN users u ON ch.user_id = u.id 
      WHERE ch.contact_id = ? AND ch.business_id = ? 
      ORDER BY ch.created_at DESC
    `, [contactId, bizId]);

    res.json({ success: true, data: history, message: 'History fetched' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const getContactDocuments = async (req, res) => {
  try {
    const contactId = req.params.id;
    const bizId = req.user.businessId;
    
    const [rows] = await pool.query(
      'SELECT * FROM user_document_upload WHERE contact_id = ? AND business_id = ? ORDER BY created_at DESC',
      [contactId, bizId]
    );
    
    res.json({ success: true, data: rows, message: 'Documents fetched' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const uploadContactDocument = async (req, res) => {
  try {
    const contactId = req.params.id;
    const bizId = req.user.businessId;
    const { documentType, notes } = req.body;
    
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded', data: null });
    
    let folder = 'media';
    if (req.file.mimetype === 'text/csv' || req.file.originalname.endsWith('.csv')) folder = 'csv';
    let fileUrl = `/uploads/${folder}/${req.file.filename}`;

    // Upload to Cloudflare R2 if configured
    if (r2Service.isConfigured()) {
      try {
        const r2Key = `${folder}/${req.file.filename}`;
        await r2Service.uploadFile({
          key: r2Key,
          filePath: req.file.path,
          contentType: req.file.mimetype || 'application/octet-stream',
          metadata: {
            contactId: String(contactId),
            originalName: encodeURIComponent(req.file.originalname)
          }
        });
        if (r2Service.publicUrl) {
          fileUrl = `${r2Service.publicUrl}/${r2Key}`;
        }
      } catch (r2Err) {
        console.error('Error uploading contact document to Cloudflare R2:', r2Err);
      }
    }
    let fileSizeStr = '';
    if (req.file.size < 1024 * 1024) {
      fileSizeStr = (req.file.size / 1024).toFixed(1) + ' KB';
    } else {
      fileSizeStr = (req.file.size / 1024 / 1024).toFixed(1) + ' MB';
    }

    // Determine extension/type visually for the frontend
    const ext = req.file.originalname.split('.').pop().toLowerCase();
    let typeIcon = 'file';
    if (['pdf'].includes(ext)) typeIcon = 'pdf';
    else if (['doc', 'docx'].includes(ext)) typeIcon = 'doc';
    else if (['zip', 'rar'].includes(ext)) typeIcon = 'zip';

    const [result] = await pool.query(
      `INSERT INTO user_document_upload 
       (contact_id, business_id, document_type, file_name, file_url, file_size, notes, uploaded_by, file_type) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [contactId, bizId, documentType || 'Other', req.file.originalname, fileUrl, fileSizeStr, notes || '', req.user.userId || null, typeIcon]
    );

    const [docs] = await pool.query('SELECT * FROM user_document_upload WHERE id = ?', [result.insertId]);

    res.json({ success: true, data: docs[0], message: 'Document uploaded' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const deleteContactDocument = async (req, res) => {
  try {
    const { id, docId } = req.params;
    const bizId = req.user.businessId;

    const [docs] = await pool.query(
      'SELECT * FROM user_document_upload WHERE id = ? AND contact_id = ? AND business_id = ?',
      [docId, id, bizId]
    );
    if (!docs || docs.length === 0) {
      return res.status(404).json({ success: false, message: 'Document not found' });
    }

    const doc = docs[0];
    if (r2Service.isConfigured() && doc.file_url) {
      let r2Key;
      if (doc.file_url.startsWith('http')) {
        try {
          const u = new URL(doc.file_url);
          r2Key = u.pathname.replace(/^\/+/, '');
        } catch (e) {
          const filename = path.basename(doc.file_url);
          const folder = doc.file_url.includes('/csv/') ? 'csv' : 'media';
          r2Key = `${folder}/${filename}`;
        }
      } else {
        const filename = path.basename(doc.file_url);
        const folder = doc.file_url.includes('/csv/') ? 'csv' : 'media';
        r2Key = `${folder}/${filename}`;
      }
      await r2Service.deleteFile(r2Key);
    }

    await pool.query('DELETE FROM user_document_upload WHERE id = ?', [docId]);
    res.json({ success: true, message: 'Document deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// ── Excel Import Helpers & Flexible Date Parsers ──────────────
const isBulkImportLeadsEnabled = (req) => {
  if (req.body && req.body.useBulkImportLeads !== undefined) {
    return String(req.body.useBulkImportLeads) === 'true' || req.body.useBulkImportLeads === 1;
  }
  return process.env.ENABLE_IMPORTED_LEADS_BULK === 'true' || process.env.ENABLE_IMPORTED_LEADS_BULK === '1';
};

const parseFlexibleDate = (val) => {
  if (!val) return null;
  if (val instanceof Date && !isNaN(val.getTime())) {
    const y = val.getFullYear();
    const m = String(val.getMonth() + 1).padStart(2, '0');
    const d = String(val.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  if (typeof val === 'number') {
    // Excel serial number (days since Dec 30, 1899)
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const jsDate = new Date(excelEpoch.getTime() + val * 86400000);
    if (!isNaN(jsDate.getTime())) {
      const y = jsDate.getUTCFullYear();
      const m = String(jsDate.getUTCMonth() + 1).padStart(2, '0');
      const d = String(jsDate.getUTCDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }
  }
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (!trimmed) return null;
    const mIso = trimmed.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
    if (mIso) {
      return `${mIso[1]}-${String(mIso[2]).padStart(2, '0')}-${String(mIso[3]).padStart(2, '0')}`;
    }
    const mDmy = trimmed.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
    if (mDmy) {
      return `${mDmy[3]}-${String(mDmy[2]).padStart(2, '0')}-${String(mDmy[1]).padStart(2, '0')}`;
    }
    const d = new Date(trimmed);
    if (!isNaN(d.getTime())) {
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      return `${y}-${m}-${day}`;
    }
  }
  return null;
};

const parseFlexibleDateTime = (val) => {
  if (!val) return null;
  if (val instanceof Date && !isNaN(val.getTime())) {
    return val;
  }
  if (typeof val === 'number') {
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const jsDate = new Date(excelEpoch.getTime() + val * 86400000);
    if (!isNaN(jsDate.getTime())) return jsDate;
  }
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (!trimmed) return null;
    const d = new Date(trimmed);
    if (!isNaN(d.getTime())) return d;
    const dateStr = parseFlexibleDate(trimmed);
    if (dateStr) return new Date(dateStr);
  }
  return null;
};

// Flexible case-insensitive column finder across ANY Excel headers
const getCol = (row, keywords) => {
  if (!row || typeof row !== 'object') return '';
  const keys = Object.keys(row);
  for (const kw of keywords) {
    const found = keys.find(k => k.trim().toLowerCase() === kw.toLowerCase());
    if (found && row[found] !== undefined && row[found] !== null && String(row[found]).trim() !== '') {
      return String(row[found]).trim();
    }
  }
  // Partial match fallback
  for (const kw of keywords) {
    const found = keys.find(k => k.trim().toLowerCase().includes(kw.toLowerCase()));
    if (found && row[found] !== undefined && row[found] !== null && String(row[found]).trim() !== '') {
      return String(row[found]).trim();
    }
  }
  return '';
};

// ── Skip Reason Tracker for Import ─────────────────────────────
const createSkipTracker = () => {
  const counts = {
    phone_exists: 0,
    phone_missing: 0,
    phone_invalid: 0,
    phone_duplicate_in_file: 0,
    status_not_found: 0,
    empty_row: 0,
    other: 0
  };

  const labels = {
    phone_exists: 'Phone number already exists',
    phone_missing: 'Phone number is missing',
    phone_invalid: 'Phone number is invalid (must be 10 digits)',
    phone_duplicate_in_file: 'Duplicate phone number in Excel file',
    status_not_found: 'Status does not exist in the system',
    empty_row: 'Empty row (name and phone missing)',
    other: 'Other validation errors'
  };

  const record = (type) => {
    if (counts[type] !== undefined) counts[type]++;
    else counts.other++;
  };

  const getSummaryMessages = () => {
    const messages = [];
    for (const [key, count] of Object.entries(counts)) {
      if (count > 0) {
        const rowWord = count === 1 ? '1 row skipped' : `${count} rows skipped`;
        messages.push(`${rowWord} – ${labels[key] || key}.`);
      }
    }
    return messages;
  };

  const getSummaryCounts = () => {
    const summary = {};
    for (const [key, count] of Object.entries(counts)) {
      if (count > 0) summary[key] = count;
    }
    return summary;
  };

  return { counts, labels, record, getSummaryMessages, getSummaryCounts };
};

// ── Legacy row-by-row import into contacts only ─────────────────
const processLegacyImportContacts = async (conn, req, res, leads, statusAndAssignment) => {
  const bizId  = req.user.businessId;
  const userId = req.user.userId;

  const { status, branch, department, assigned_employee, remark, follow_up_date, loss_reason, channel, channel_preference, source, enquiry_for_id, enquiry_for } = statusAndAssignment || {};
  const selectedChannel = (channel_preference || channel || source || '').trim() || null;

  // Resolve Inquiry Form (enquiry_fors)
  let globalEnquiryForId = null;
  const [allEnquiryFors] = await conn.query('SELECT id, name FROM enquiry_fors WHERE business_id = ?', [bizId]);
  const enquiryMap = new Map();
  for (const ef of allEnquiryFors) {
    enquiryMap.set(String(ef.id), ef.id);
    enquiryMap.set(ef.name.toLowerCase().trim(), ef.id);
  }

  if (enquiry_for_id && enquiryMap.has(String(enquiry_for_id))) {
    globalEnquiryForId = enquiryMap.get(String(enquiry_for_id));
  } else if (enquiry_for && enquiryMap.has(String(enquiry_for).toLowerCase().trim())) {
    globalEnquiryForId = enquiryMap.get(String(enquiry_for).toLowerCase().trim());
  }

  // Resolve assigned user
  let assignedTo = null;
  if (assigned_employee) {
    const [uRows] = await conn.query('SELECT id FROM users WHERE name = ? AND business_id = ? LIMIT 1', [assigned_employee, bizId]);
    if (uRows.length > 0) assignedTo = uRows[0].id;
  }
  if (!assignedTo) assignedTo = userId;

  // Resolve branch
  let branchId = null, branchName = branch || null;
  if (branchName) {
    const [bRows] = await conn.query('SELECT id FROM branches WHERE name = ? LIMIT 1', [branchName]);
    if (bRows.length > 0) branchId = bRows[0].id;
  }

  // Resolve department
  let departmentId = null, departmentName = department || null;
  if (departmentName) {
    const [dRows] = await conn.query('SELECT id FROM departments WHERE name = ? LIMIT 1', [departmentName]);
    if (dRows.length > 0) departmentId = dRows[0].id;
  }

  // Resolve status
  const [allLegacyStatuses] = await conn.query('SELECT id, name, type FROM statuses');
  const legacyStatusMap = new Map();
  for (const s of allLegacyStatuses) {
    legacyStatusMap.set(String(s.id), s);
    legacyStatusMap.set(s.name.toLowerCase().trim(), s);
  }

  let globalLegacyStatusObj = null;
  if (status && legacyStatusMap.has(status.toLowerCase().trim())) {
    globalLegacyStatusObj = legacyStatusMap.get(status.toLowerCase().trim());
  }

  // Follow-up date
  let formattedFollowUpDate = null;
  if (follow_up_date) {
    formattedFollowUpDate = normalizeDateOnly(follow_up_date);
  }

  // User names for follow_ups record
  let byUserName = null, toUserName = null;
  const [uNameRows] = await conn.query('SELECT name FROM users WHERE id = ? LIMIT 1', [userId]);
  if (uNameRows.length) byUserName = uNameRows[0].name;
  const [tuRows] = await conn.query('SELECT name FROM users WHERE id = ? LIMIT 1', [assignedTo]);
  if (tuRows.length) toUserName = tuRows[0].name;

  if (leads.length > 0) {
    console.log('[processLegacyImportContacts] Excel column headers:', Object.keys(leads[0]));
  }

  const skipTracker = createSkipTracker();
  let inserted = 0, skipped = 0;
  const errors = [];
  const invalidEmails = [];
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  for (let rowIndex = 0; rowIndex < leads.length; rowIndex++) {
    const row = leads[rowIndex];
    const actualRowNumber = rowIndex + 2;
    try {
      const name    = getCol(row, ['Name', 'Full Name', 'Customer Name', 'Student Name', 'Client Name', 'Lead Name', 'Contact Name', 'Person Name', 'Applicant Name', 'Candidate Name']);
      let   phone   = getCol(row, ['Phone', 'Mobile', 'Phone Number', 'Mobile Number', 'Mobile No', 'Phone No', 'Contact Number', 'Contact No', 'Whatsapp', 'WhatsApp No', 'Cell', 'Tel', 'Telephone', 'Number', 'Contact']);
      let   email   = getCol(row, ['Email', 'Email Address', 'Mail', 'E-Mail', 'Email Id', 'Email ID']) || null;
      const tags    = getCol(row, ['Tags', 'Tag', 'Labels', 'Category', 'Course', 'Program']);
      const address = getCol(row, ['Address', 'Location', 'City', 'Place', 'Area']) || null;
      const rowChannel = getCol(row, ['Source', 'Lead Source', 'Channel', 'Channel Preference', 'Origin', 'Medium']);
      const finalChannel = (selectedChannel || rowChannel || 'whatsapp').trim().slice(0, 100);

      const rowEnquiry = getCol(row, ['Inquiry Form', 'Inquiry Form Name', 'Enquiry Form', 'Enquiry Form Name', 'Inquiry For', 'Enquiry For', 'Inquiry', 'Enquiry']);
      let rowEnquiryForId = globalEnquiryForId;
      if (rowEnquiry) {
        const cleanEnq = rowEnquiry.trim().toLowerCase();
        if (enquiryMap.has(cleanEnq)) {
          rowEnquiryForId = enquiryMap.get(cleanEnq);
        } else if (enquiryMap.has(rowEnquiry.trim())) {
          rowEnquiryForId = enquiryMap.get(rowEnquiry.trim());
        }
      }

      if (!name && !phone) {
        skipped++;
        skipTracker.record('empty_row');
        continue;
      }

      if (email) {
        email = email.trim();
        if (!emailRegex.test(email)) {
          invalidEmails.push({
            row: actualRowNumber,
            name: name || 'Unnamed Lead',
            email: email,
            error: 'Invalid email format'
          });
          email = null;
        }
      }

      if (!phone) {
        skipped++;
        skipTracker.record('phone_missing');
        errors.push(`Row ${actualRowNumber}: Phone number missing`);
        continue;
      }

      phone = phone.replace(/\D/g, '');
      if (phone.length === 10) phone = '91' + phone;
      if (phone.length !== 12) {
        skipped++;
        skipTracker.record('phone_invalid');
        errors.push('Skipped "' + (name || phone) + '": phone invalid (got ' + phone.length + ' digits after cleaning: ' + phone + ')');
        continue;
      }
      const last10 = phone.slice(-10);
      const [dupRows] = await conn.query('SELECT id FROM contacts WHERE business_id = ? AND phone LIKE ? LIMIT 1', [bizId, '%' + last10]);
      if (dupRows.length > 0) {
        skipped++;
        skipTracker.record('phone_exists');
        errors.push('Skipped "' + name + '": phone ' + phone + ' already exists');
        continue;
      }

      // Check status: skip entire row if a new/unrecognized status is found
      const rowStatus = getCol(row, ['Status', 'Lead Status', 'Current Status', 'Stage']);
      let sObj = globalLegacyStatusObj;
      if (rowStatus && String(rowStatus).trim()) {
        const cleanRowStatus = String(rowStatus).toLowerCase().trim();
        if (!legacyStatusMap.has(cleanRowStatus)) {
          skipped++;
          skipTracker.record('status_not_found');
          errors.push(`Row ${actualRowNumber}: Skipped "${name || phone}": status "${String(rowStatus).trim()}" does not exist in the system`);
          continue;
        }
        sObj = legacyStatusMap.get(cleanRowStatus);
      } else if (status && String(status).trim() && !globalLegacyStatusObj) {
        skipped++;
        skipTracker.record('status_not_found');
        errors.push(`Row ${actualRowNumber}: Skipped "${name || phone}": status "${String(status).trim()}" does not exist in the system`);
        continue;
      }

      const rowStatusId = sObj ? sObj.id : null;
      const rowStatusName = sObj ? sObj.name : null;
      let row_current_sale_status = 0;
      let row_sale_won = 0, row_sale_lost = 0, row_sale_won_date = null, row_sale_lost_date = null, row_sale_won_by = null, row_sale_lost_by = null;
      if (sObj) {
        if (sObj.type === 'sale') {
          row_current_sale_status = 1;
          row_sale_won = 1;
          row_sale_won_date = new Date();
          row_sale_won_by = assignedTo;
        } else if (sObj.type === 'sale_lost') {
          row_current_sale_status = 2;
          row_sale_lost = 1;
          row_sale_lost_date = new Date();
          row_sale_lost_by = assignedTo;
        }
      }

      const tagsArray = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
      const userList  = [assignedTo];

      // Resolve Channel via Stored Procedure sp_resolve_or_create_channel
      let rowChannelId = null;
      let rowResolvedChannel = finalChannel;
      try {
        await conn.query('CALL sp_resolve_or_create_channel(?, ?, @cid, @cname)', [bizId, finalChannel]);
        const [[chRes]] = await conn.query('SELECT @cid AS channel_id, @cname AS channel_name');
        if (chRes) {
          rowChannelId = chRes.channel_id || null;
          rowResolvedChannel = chRes.channel_name || finalChannel;
        }
      } catch (chErr) {
        console.warn('[processLegacyImportContacts] Channel SP warning:', chErr.message);
      }

      const [result] = await conn.query(
        'INSERT INTO contacts (business_id, name, phone, email, tags, channel_id, channel_preference, assigned_to, address, follow_up_date, follow_up, branch_id, branch_name, department_id, department_name, status_id, status_name, current_sale_status, sale_won, sale_won_date, sale_won_by, sale_lost, sale_lost_date, sale_lost_by, created_by_user, user_list, loss_reason, opt_in_source, enquiry_for_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [bizId, name || null, phone || null, email, JSON.stringify(tagsArray), rowChannelId, rowResolvedChannel, assignedTo, address, formattedFollowUpDate, formattedFollowUpDate ? 1 : 0, branchId, branchName, departmentId, departmentName, rowStatusId, rowStatusName, row_current_sale_status, row_sale_won, row_sale_won_date, row_sale_won_by, row_sale_lost, row_sale_lost_date, row_sale_lost_by, userId, JSON.stringify(userList), loss_reason || null, 'import', rowEnquiryForId || null]
      );
      const contactId = result.insertId;

      await conn.query(
        'INSERT INTO follow_ups (contact_id, contact_name, follow_up_date, by_user_id, by_user_name, to_user_id, to_user_name, status_id, status_name, branch_id, branch_name, department_id, department_name, remarks) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
        [contactId, name || null, formattedFollowUpDate, userId, byUserName, assignedTo, toUserName, rowStatusId, rowStatusName, branchId, branchName, departmentId, departmentName, remark || 'Imported via Excel']
      );

      inserted++;
    } catch (rowErr) {
      skipped++;
      skipTracker.record('other');
      console.error('[processLegacyImportContacts] row error:', rowErr.message, rowErr);
      errors.push(rowErr.message);
    }
  }

  await conn.commit();

  const detectedCols = leads.length > 0 ? Object.keys(leads[0]) : [];
  const skipMessages = skipTracker.getSummaryMessages();
  const summaryLine = skipMessages.length > 0 ? '\n\n' + skipMessages.join('\n') : '';

  if (inserted === 0) {
    return res.json({
      success: false,
      message: `0 leads imported. ${skipped} row(s) skipped.${summaryLine}`,
      data: {
        inserted: 0,
        skipped,
        skipMessages,
        skipSummary: skipTracker.getSummaryCounts(),
        errors,
        invalidEmails,
        detectedColumns: detectedCols,
        bulkMode: false
      }
    });
  }
  return res.json({
    success: true,
    message: `Import complete. ${inserted} lead(s) imported.${summaryLine}`,
    data: {
      inserted,
      skipped,
      skipMessages,
      skipSummary: skipTracker.getSummaryCounts(),
      errors,
      invalidEmails,
      detectedColumns: detectedCols,
      bulkMode: false
    }
  });
};

// ── Bulk Insert with Dual-Table Synchronization (contacts + imported_leads) ──
const processBulkImportContacts = async (conn, req, res, leads, statusAndAssignment) => {
  const bizId  = req.user.businessId;
  const userId = req.user.userId;

  const {
    status: defaultStatus,
    branch: defaultBranch,
    department: defaultDepartment,
    assigned_employee: defaultAssignedEmployee,
    remark: defaultRemark,
    follow_up_date: defaultFollowUpDate,
    loss_reason: defaultLossReason,
    channel: defaultChannel,
    channel_preference: defaultChannelPref,
    source: defaultSource,
    enquiry_for_id: defaultEnquiryForId,
    enquiry_for: defaultEnquiryFor
  } = statusAndAssignment || {};

  const globalSelectedChannel = (defaultChannelPref || defaultChannel || defaultSource || '').trim() || null;

  // 1. Pre-fetch metadata in parallel
  const [
    [enquiryRows],
    [branchRows],
    [deptRows],
    [userRows],
    [statusRows]
  ] = await Promise.all([
    conn.query('SELECT id, name FROM enquiry_fors WHERE business_id = ?', [bizId]),
    conn.query('SELECT id, name FROM branches'),
    conn.query('SELECT id, branch_id, name FROM departments'),
    conn.query('SELECT id, name, branch_id, department_id FROM users WHERE business_id = ?', [bizId]),
    conn.query('SELECT id, name, type FROM statuses')
  ]);

  // Build lookup maps
  const enquiryMap = new Map();
  for (const ef of enquiryRows) {
    enquiryMap.set(String(ef.id), ef);
    enquiryMap.set(ef.name.toLowerCase().trim(), ef);
  }

  const branchMap = new Map();
  for (const b of branchRows) {
    branchMap.set(String(b.id), b);
    branchMap.set(b.name.toLowerCase().trim(), b);
  }

  const deptMap = new Map();
  for (const d of deptRows) {
    deptMap.set(String(d.id), d);
    deptMap.set(d.name.toLowerCase().trim(), d);
    if (d.branch_id) {
      deptMap.set(`${d.branch_id}_${d.name.toLowerCase().trim()}`, d);
    }
  }

  const userMap = new Map();
  for (const u of userRows) {
    userMap.set(String(u.id), u);
    userMap.set(u.name.toLowerCase().trim(), u);
  }

  const statusMap = new Map();
  for (const s of statusRows) {
    statusMap.set(String(s.id), s);
    statusMap.set(s.name.toLowerCase().trim(), s);
  }

  // Pre-resolve global defaults
  let globalEnquiryForObj = null;
  if (defaultEnquiryForId && enquiryMap.has(String(defaultEnquiryForId))) {
    globalEnquiryForObj = enquiryMap.get(String(defaultEnquiryForId));
  } else if (defaultEnquiryFor && enquiryMap.has(String(defaultEnquiryFor).toLowerCase().trim())) {
    globalEnquiryForObj = enquiryMap.get(String(defaultEnquiryFor).toLowerCase().trim());
  }

  let globalAssignedUserObj = null;
  if (defaultAssignedEmployee && userMap.has(defaultAssignedEmployee.toLowerCase().trim())) {
    globalAssignedUserObj = userMap.get(defaultAssignedEmployee.toLowerCase().trim());
  } else if (userMap.has(String(userId))) {
    globalAssignedUserObj = userMap.get(String(userId));
  }

  let globalBranchObj = null;
  if (defaultBranch && branchMap.has(defaultBranch.toLowerCase().trim())) {
    globalBranchObj = branchMap.get(defaultBranch.toLowerCase().trim());
  }

  let globalDeptObj = null;
  if (defaultDepartment && deptMap.has(defaultDepartment.toLowerCase().trim())) {
    globalDeptObj = deptMap.get(defaultDepartment.toLowerCase().trim());
  }

  let globalStatusObj = null;
  if (defaultStatus && statusMap.has(defaultStatus.toLowerCase().trim())) {
    globalStatusObj = statusMap.get(defaultStatus.toLowerCase().trim());
  }

  const globalFormattedFollowUpDate = parseFlexibleDate(defaultFollowUpDate);

  const currentUserObj = userMap.get(String(userId)) || { id: userId, name: 'System' };
  const byUserName = currentUserObj.name || null;

  // 2. Validate, map, and prepare candidate rows
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  const candidateRows = [];
  const skipTracker = createSkipTracker();
  let skipped = 0;
  const errors = [];
  const invalidEmails = [];
  const seenPhoneLast10InFile = new Set();

  for (let rowIndex = 0; rowIndex < leads.length; rowIndex++) {
    const row = leads[rowIndex];
    const actualRowNumber = rowIndex + 2;

    const name = getCol(row, ['Name', 'Full Name', 'Customer Name', 'Student Name', 'Client Name', 'Lead Name', 'Contact Name', 'Person Name', 'Applicant Name', 'Candidate Name']);
    let phone = getCol(row, ['Phone', 'Mobile', 'Phone Number', 'Mobile Number', 'Mobile No', 'Phone No', 'Contact Number', 'Contact No', 'Whatsapp', 'WhatsApp No', 'Cell', 'Tel', 'Telephone', 'Number', 'Contact']);
    let email = getCol(row, ['Email', 'Email Address', 'Mail', 'E-Mail', 'Email Id', 'Email ID']) || null;
    const tags = getCol(row, ['Tags', 'Tag', 'Labels', 'Category', 'Course', 'Program']);
    const address = getCol(row, ['Address', 'Location', 'City', 'Place', 'Area']) || null;

    if (!name && !phone) {
      skipped++;
      skipTracker.record('empty_row');
      continue;
    }

    if (email) {
      email = email.trim();
      if (!emailRegex.test(email)) {
        invalidEmails.push({
          row: actualRowNumber,
          name: name || 'Unnamed Lead',
          email: email,
          error: 'Invalid email format'
        });
        email = null;
      }
    }

    if (!phone) {
      skipped++;
      skipTracker.record('phone_missing');
      errors.push(`Row ${actualRowNumber}: Phone number missing`);
      continue;
    }

    phone = phone.replace(/\D/g, '');
    if (phone.length === 10) phone = '91' + phone;
    if (phone.length !== 12) {
      skipped++;
      skipTracker.record('phone_invalid');
      errors.push(`Skipped "${name || phone}": phone invalid (got ${phone.length} digits: ${phone})`);
      continue;
    }

    const last10 = phone.slice(-10);
    if (seenPhoneLast10InFile.has(last10)) {
      skipped++;
      skipTracker.record('phone_duplicate_in_file');
      errors.push(`Skipped "${name || phone}": duplicate phone in Excel file (${phone})`);
      continue;
    }
    seenPhoneLast10InFile.add(last10);

    // Resolve Enquiry Form (Priority: Excel -> UI selection -> null)
    const rowEnquiry = getCol(row, ['Inquiry Form', 'Inquiry Form Name', 'Enquiry Form', 'Enquiry Form Name', 'Inquiry For', 'Enquiry For', 'Inquiry', 'Enquiry', 'Course', 'Program']);
    let efObj = globalEnquiryForObj;
    if (rowEnquiry && enquiryMap.has(rowEnquiry.toLowerCase().trim())) {
      efObj = enquiryMap.get(rowEnquiry.toLowerCase().trim());
    }
    const enquiryForId = efObj ? efObj.id : null;
    const enquiryForName = efObj ? efObj.name : (rowEnquiry || null);

    // Resolve Source / Channel Preference (Priority: Excel -> UI selection -> 'whatsapp')
    const rowSource = getCol(row, ['Source', 'Lead Source', 'Channel', 'Channel Preference', 'Origin', 'Medium']);
    const finalSource = (rowSource || globalSelectedChannel || 'whatsapp').trim().slice(0, 100);

    // Resolve Branch (Priority: Excel -> UI selection -> null)
    const rowBranch = getCol(row, ['Branch', 'Branch Name', 'Location Branch']);
    let bObj = globalBranchObj;
    if (rowBranch && branchMap.has(rowBranch.toLowerCase().trim())) {
      bObj = branchMap.get(rowBranch.toLowerCase().trim());
    }
    const branchId = bObj ? bObj.id : null;
    const branchName = bObj ? bObj.name : (rowBranch || null);

    // Resolve Department (Priority: Excel -> UI selection -> null)
    const rowDept = getCol(row, ['Department', 'Dept', 'Department Name']);
    let dObj = globalDeptObj;
    if (rowDept) {
      if (branchId && deptMap.has(`${branchId}_${rowDept.toLowerCase().trim()}`)) {
        dObj = deptMap.get(`${branchId}_${rowDept.toLowerCase().trim()}`);
      } else if (deptMap.has(rowDept.toLowerCase().trim())) {
        dObj = deptMap.get(rowDept.toLowerCase().trim());
      }
    }
    const departmentId = dObj ? dObj.id : null;
    const departmentName = dObj ? dObj.name : (rowDept || null);

    // Resolve Assigned User (Priority: Excel -> UI selection -> current user)
    const rowUser = getCol(row, ['Assigned User', 'Assigned To', 'Assigned Employee', 'Counselor', 'Agent', 'Staff', 'Employee']);
    let uObj = globalAssignedUserObj;
    if (rowUser && userMap.has(rowUser.toLowerCase().trim())) {
      uObj = userMap.get(rowUser.toLowerCase().trim());
    }
    const assignedTo = uObj ? uObj.id : userId;
    const assignedUserName = uObj ? uObj.name : byUserName;

    // Resolve Status (Priority: Excel -> UI selection -> null)
    // If a new status is found that does not already exist in the system, skip that entire row during import
    const rowStatus = getCol(row, ['Status', 'Lead Status', 'Current Status', 'Stage']);
    let sObj = globalStatusObj;
    if (rowStatus && String(rowStatus).trim()) {
      const cleanRowStatus = String(rowStatus).toLowerCase().trim();
      if (!statusMap.has(cleanRowStatus)) {
        skipped++;
        skipTracker.record('status_not_found');
        errors.push(`Row ${actualRowNumber}: Skipped "${name || phone}": status "${String(rowStatus).trim()}" does not exist in the system`);
        continue;
      }
      sObj = statusMap.get(cleanRowStatus);
    } else if (defaultStatus && String(defaultStatus).trim() && !globalStatusObj) {
      skipped++;
      skipTracker.record('status_not_found');
      errors.push(`Row ${actualRowNumber}: Skipped "${name || phone}": status "${String(defaultStatus).trim()}" does not exist in the system`);
      continue;
    }
    const statusId = sObj ? sObj.id : null;
    const statusName = sObj ? sObj.name : null;

    let current_sale_status = 0;
    let sale_won = 0, sale_lost = 0;
    let sale_won_date = null, sale_lost_date = null;
    let sale_won_by = null, sale_lost_by = null;
    if (sObj) {
      if (sObj.type === 'sale') {
        current_sale_status = 1;
        sale_won = 1;
        sale_won_date = new Date();
        sale_won_by = assignedTo;
      } else if (sObj.type === 'sale_lost') {
        current_sale_status = 2;
        sale_lost = 1;
        sale_lost_date = new Date();
        sale_lost_by = assignedTo;
      }
    }

    // Resolve Follow-up Date (Priority: Excel -> UI selection -> null)
    const rowFollowUpDate = getCol(row, ['Follow-up Date', 'Follow Up Date', 'Followup Date', 'Follow Up', 'Next Follow-up', 'Next Followup', 'Reminder Date']);
    const formattedFollowUpDate = parseFlexibleDate(rowFollowUpDate) || globalFormattedFollowUpDate;
    const followUpFlag = formattedFollowUpDate ? 1 : 0;

    // Resolve Lead Date / Created Date (Priority: Excel -> NOW())
    const rowDate = getCol(row, ['Date', 'Lead Date', 'Created Date', 'Inquiry Date', 'Enquiry Date', 'Entry Date', 'Registration Date']);
    const leadDateTime = parseFlexibleDateTime(rowDate) || new Date();

    // Resolve Loss Reason
    const rowLossReason = getCol(row, ['Loss Reason', 'Reason for Loss']);
    const lossReason = rowLossReason || defaultLossReason || null;

    // Resolve Remark
    const rowRemark = getCol(row, ['Remark', 'Remarks', 'Note', 'Notes', 'Comment', 'Comments']);
    const remark = rowRemark || defaultRemark || 'Imported via Excel';

    const tagsArray = tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [];
    const userList = [assignedTo];

    candidateRows.push({
      actualRowNumber,
      name: name || null,
      phone,
      country_code: '+91',
      last10,
      email,
      address,
      tags: tagsArray,
      tagsJson: JSON.stringify(tagsArray),
      source: finalSource,
      channel_preference: finalSource,
      enquiry_for_id: enquiryForId,
      enquiry_for_name: enquiryForName,
      status_id: statusId,
      status_name: statusName,
      current_sale_status,
      sale_won,
      sale_won_date,
      sale_won_by,
      sale_lost,
      sale_lost_date,
      sale_lost_by,
      lead_date: leadDateTime,
      follow_up_date: formattedFollowUpDate,
      follow_up: followUpFlag,
      branch_id: branchId,
      branch_name: branchName,
      department_id: departmentId,
      department_name: departmentName,
      assigned_to: assignedTo,
      assigned_user_name: assignedUserName,
      loss_reason: lossReason,
      remark,
      created_by_user: userId,
      user_list: userList,
      user_listJson: JSON.stringify(userList),
      raw_data: JSON.stringify(row)
    });
  }

  // 3. Batch duplicate check against database in one or chunked queries
  const readyToInsertRows = [];
  if (candidateRows.length > 0) {
    const candidateSuffixes = candidateRows.map(r => r.last10);
    const chunkSize = 2000;
    const existingPhoneSuffixes = new Set();
    for (let i = 0; i < candidateSuffixes.length; i += chunkSize) {
      const slice = candidateSuffixes.slice(i, i + chunkSize);
      const [dupRows] = await conn.query(
        'SELECT phone FROM contacts WHERE business_id = ? AND RIGHT(phone, 10) IN (?)',
        [bizId, slice]
      );
      for (const d of dupRows) {
        const p10 = String(d.phone).replace(/\D/g, '').slice(-10);
        if (p10) existingPhoneSuffixes.add(p10);
      }
    }

    for (const r of candidateRows) {
      if (existingPhoneSuffixes.has(r.last10)) {
        skipped++;
        skipTracker.record('phone_exists');
        errors.push(`Skipped "${r.name || r.phone}": phone ${r.phone} already exists`);
      } else {
        readyToInsertRows.push(r);
      }
    }
  }

  const detectedCols = leads.length > 0 ? Object.keys(leads[0]) : [];
  const skipMessages = skipTracker.getSummaryMessages();
  const summaryLine = skipMessages.length > 0 ? '\n\n' + skipMessages.join('\n') : '';

  if (readyToInsertRows.length === 0) {
    await conn.rollback();
    return res.json({
      success: false,
      message: `0 leads imported. ${skipped} row(s) skipped.${summaryLine}`,
      data: {
        inserted: 0,
        skipped,
        skipMessages,
        skipSummary: skipTracker.getSummaryCounts(),
        errors,
        invalidEmails,
        detectedColumns: detectedCols,
        bulkMode: true
      }
    });
  }

  // 4. Resolve / create channels for unique sources using Stored Procedure sp_resolve_or_create_channel
  const uniqueSources = Array.from(new Set(readyToInsertRows.map(r => r.source || 'whatsapp')));
  const channelResolutionMap = new Map();

  for (const src of uniqueSources) {
    const cleanSrc = (src || 'whatsapp').trim().slice(0, 100);
    const lowerKey = cleanSrc.toLowerCase();
    if (!channelResolutionMap.has(lowerKey)) {
      try {
        await conn.query('CALL sp_resolve_or_create_channel(?, ?, @cid, @cname)', [bizId, cleanSrc]);
        const [[res]] = await conn.query('SELECT @cid AS channel_id, @cname AS channel_name');
        if (res) {
          channelResolutionMap.set(lowerKey, {
            id: res.channel_id,
            name: res.channel_name
          });
        }
      } catch (chErr) {
        console.warn('[processBulkImportContacts] Channel SP warning for ' + cleanSrc + ':', chErr.message);
        channelResolutionMap.set(lowerKey, { id: null, name: cleanSrc });
      }
    }
  }

  for (const r of readyToInsertRows) {
    const lowerKey = (r.source || 'whatsapp').trim().slice(0, 100).toLowerCase();
    const mapped = channelResolutionMap.get(lowerKey);
    r.channel_id = mapped ? mapped.id : null;
    r.channel_preference = mapped ? mapped.name : (r.source || 'whatsapp');
  }

  // 5. Atomic Bulk Insertion into `contacts`, `imported_leads`, and `follow_ups`
  const importBatchId = 'batch_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
  const BATCH_SIZE = 500;
  let inserted = 0;

  for (let b = 0; b < readyToInsertRows.length; b += BATCH_SIZE) {
    const chunk = readyToInsertRows.slice(b, b + BATCH_SIZE);

    // a) Contacts multi-row values
    const contactsMultiValues = chunk.map(r => [
      bizId,
      r.name,
      r.phone,
      r.country_code,
      r.email,
      r.tagsJson,
      r.channel_id,
      r.channel_preference,
      r.assigned_to,
      r.address,
      r.follow_up_date,
      r.follow_up,
      r.branch_id,
      r.branch_name,
      r.department_id,
      r.department_name,
      r.status_id,
      r.status_name,
      r.current_sale_status,
      r.sale_won,
      r.sale_won_date,
      r.sale_won_by,
      r.sale_lost,
      r.sale_lost_date,
      r.sale_lost_by,
      r.created_by_user,
      r.user_listJson,
      r.loss_reason,
      'import',
      r.enquiry_for_id,
      r.lead_date
    ]);

    const [contactInsertResult] = await conn.query(
      `INSERT INTO contacts (
        business_id, name, phone, country_code, email, tags,
        channel_id, channel_preference, assigned_to, address, follow_up_date, follow_up,
        branch_id, branch_name, department_id, department_name,
        status_id, status_name, current_sale_status,
        sale_won, sale_won_date, sale_won_by,
        sale_lost, sale_lost_date, sale_lost_by,
        created_by_user, user_list, loss_reason, opt_in_source, enquiry_for_id,
        created_at
      ) VALUES ?`,
      [contactsMultiValues]
    );

    const firstContactId = contactInsertResult.insertId;

    // b) Imported Leads multi-row values (identical data + linked contact_id)
    const importedLeadsMultiValues = chunk.map((r, idx) => [
      bizId,
      firstContactId + idx,
      importBatchId,
      r.name,
      r.phone,
      r.country_code,
      r.email,
      r.address,
      r.tagsJson,
      'import',
      r.channel_id,
      r.channel_preference,
      r.source,
      r.enquiry_for_id,
      r.enquiry_for_name,
      r.status_id,
      r.status_name,
      r.lead_date,
      r.follow_up_date,
      r.follow_up,
      r.branch_id,
      r.branch_name,
      r.department_id,
      r.department_name,
      r.assigned_to,
      r.assigned_user_name,
      r.current_sale_status,
      r.sale_won,
      r.sale_won_date,
      r.sale_won_by,
      r.sale_lost,
      r.sale_lost_date,
      r.sale_lost_by,
      r.loss_reason,
      r.created_by_user,
      r.user_listJson,
      r.raw_data,
      r.lead_date
    ]);

    await conn.query(
      `INSERT INTO imported_leads (
        business_id, contact_id, import_batch_id,
        name, phone, country_code, email, address, tags,
        opt_in_source, channel_id, channel_preference, source,
        enquiry_for_id, enquiry_for_name,
        status_id, status_name,
        lead_date, follow_up_date, follow_up,
        branch_id, branch_name, department_id, department_name,
        assigned_to, assigned_user_name,
        current_sale_status, sale_won, sale_won_date, sale_won_by,
        sale_lost, sale_lost_date, sale_lost_by,
        loss_reason, created_by_user, user_list,
        raw_data, created_at
      ) VALUES ?`,
      [importedLeadsMultiValues]
    );

    // c) Follow-ups multi-row values
    const followUpsMultiValues = chunk.map((r, idx) => [
      firstContactId + idx,
      r.name,
      r.follow_up_date,
      userId,
      byUserName,
      r.assigned_to,
      r.assigned_user_name,
      r.status_id,
      r.status_name,
      r.branch_id,
      r.branch_name,
      r.department_id,
      r.department_name,
      r.remark
    ]);

    await conn.query(
      `INSERT INTO follow_ups (
        contact_id, contact_name, follow_up_date,
        by_user_id, by_user_name, to_user_id, to_user_name,
        status_id, status_name, branch_id, branch_name,
        department_id, department_name, remarks
      ) VALUES ?`,
      [followUpsMultiValues]
    );

    inserted += chunk.length;
  }

  await conn.commit();

  const finalSkipMessages = skipTracker.getSummaryMessages();
  const finalSummaryLine = finalSkipMessages.length > 0 ? '\n\n' + finalSkipMessages.join('\n') : '';

  return res.json({
    success: true,
    message: `Import complete. ${inserted} lead(s) imported.${finalSummaryLine}`,
    data: {
      inserted,
      skipped,
      skipMessages: finalSkipMessages,
      skipSummary: skipTracker.getSummaryCounts(),
      errors,
      invalidEmails,
      detectedColumns: detectedCols,
      importBatchId,
      bulkMode: true
    }
  });
};

const importExcelContacts = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const { leads, statusAndAssignment } = req.body;

    if (!leads || !Array.isArray(leads) || leads.length === 0) {
      await conn.rollback();
      conn.release();
      return res.status(400).json({ success: false, message: 'No lead data provided.', data: null });
    }

    if (isBulkImportLeadsEnabled(req)) {
      return await processBulkImportContacts(conn, req, res, leads, statusAndAssignment);
    } else {
      return await processLegacyImportContacts(conn, req, res, leads, statusAndAssignment);
    }
  } catch (err) {
    if (conn) await conn.rollback();
    console.error('[importExcelContacts] fatal:', err);
    return res.status(500).json({ success: false, message: err.message, data: null });
  } finally {
    if (conn) conn.release();
  }
};
const brevoService = require('../services/brevo.service');

// Helper to build filtering WHERE clause matching getContacts
const buildContactFilterWhere = (bizId, user, { channel, status, tag, search, agent, transferred_only }) => {
  let where = 'WHERE c.business_id = ?';
  const params = [bizId];

  if (user.role === 'agent') {
    const selfId = Number(user.userId);
    if (transferred_only === 'true') {
      where += ` AND (JSON_CONTAINS(c.user_list, JSON_QUOTE(?)) OR JSON_CONTAINS(c.user_list, ?)) AND (c.assigned_to != ? OR c.assigned_to IS NULL)`;
      params.push(selfId.toString(), selfId.toString(), selfId);
    } else {
      where += ` AND (c.assigned_to = ? OR JSON_CONTAINS(c.user_list, JSON_QUOTE(?)) OR JSON_CONTAINS(c.user_list, ?))`;
      params.push(selfId, selfId.toString(), selfId.toString());
    }
  } else {
    if (transferred_only === 'true') {
      if (agent) {
        where += ` AND (JSON_CONTAINS(c.user_list, JSON_QUOTE(?)) OR JSON_CONTAINS(c.user_list, ?)) AND (c.assigned_to != ? OR c.assigned_to IS NULL)`;
        params.push(agent.toString(), agent, agent);
      } else {
        where += ` AND JSON_LENGTH(c.user_list) > 1`;
      }
    } else if (agent) {
      where += ' AND c.assigned_to = ?';
      params.push(agent);
    }
  }

  if (channel) {
    where += ' AND c.channel_preference = ?';
    params.push(channel);
  }
  const sLower = (status || '').trim().toLowerCase();
  const isNoFollowUpFilter = sLower === 'status is not follow up' || 
                             sLower === 'not follow up' || 
                             sLower === 'no follow up' || 
                             sLower === 'no_followup' || 
                             sLower === 'no date';

  if (isNoFollowUpFilter) {
    where += ' AND c.follow_up_date IS NULL';
  } else if (status) {
    where += ' AND c.status_name = ?';
    params.push(status);
  }
  if (search) {
    where += ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)';
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (tag) {
    where += ' AND JSON_CONTAINS(c.tags, ?)';
    params.push(JSON.stringify(tag));
  }

  return { where, params };
};

/**
 * Preview recipients for bulk email send
 * Supports filtering by channel, status, tag, search, agent, transferred_only
 * AND optional selected_contact_ids (if user checked specific leads)
 */
const previewBulkEmail = async (req, res) => {
  try {
    const bizId = req.user.businessId;
    const { channel, status, tag, search, agent, transferred_only, selected_contact_ids } = req.body;
    let { where, params } = buildContactFilterWhere(bizId, req.user, { channel, status, tag, search, agent, transferred_only });

    if (Array.isArray(selected_contact_ids) && selected_contact_ids.length > 0) {
      where += ` AND c.id IN (${selected_contact_ids.map(() => '?').join(',')})`;
      params.push(...selected_contact_ids.map(id => Number(id)));
    }

    const [rows] = await pool.query(`
      SELECT c.id, c.name, c.email, c.phone, c.status_name
      FROM contacts c
      ${where}
      ORDER BY c.id DESC
    `, params);

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const validRecipients = [];
    const invalidRecipients = [];
    const missingRecipients = [];

    rows.forEach(contact => {
      const rawEmail = contact.email ? String(contact.email).trim() : '';
      if (!rawEmail) {
        missingRecipients.push({
          id: contact.id,
          name: contact.name || 'Unnamed Lead',
          phone: contact.phone || null,
          error: 'Missing email address'
        });
      } else if (!emailRegex.test(rawEmail)) {
        invalidRecipients.push({
          id: contact.id,
          name: contact.name || 'Unnamed Lead',
          email: rawEmail,
          phone: contact.phone || null,
          error: 'Invalid email format'
        });
      } else {
        validRecipients.push({
          id: contact.id,
          name: contact.name || 'Unnamed Lead',
          email: rawEmail,
          phone: contact.phone || null
        });
      }
    });

    return res.json({
      success: true,
      data: {
        totalMatched: rows.length,
        validCount: validRecipients.length,
        invalidCount: invalidRecipients.length,
        missingCount: missingRecipients.length,
        validRecipients: validRecipients,
        invalidRecipients: invalidRecipients,
        missingRecipients: missingRecipients // Full list of missing
      }
    });
  } catch (err) {
    console.error('[previewBulkEmail] error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

/**
 * Send bulk email via Brevo to valid recipients matching filters or selected IDs
 * Saves rendered email record per recipient in lead_emails with initial status 'queued'
 */
const sendBulkEmail = async (req, res) => {
  try {
    const bizId = req.user.businessId;
    const { channel, status, tag, search, agent, transferred_only, selected_contact_ids, template_id, subject, body, attachments, attachment } = req.body;

    const rawAttachments = attachments || attachment || [];
    const validAttachments = Array.isArray(rawAttachments)
      ? rawAttachments
          .map(a => ({
            name: (a.name || 'attachment').trim(),
            content: a.content ? String(a.content).replace(/^data:[^;]+;base64,/, '').trim() : undefined,
            url: a.url ? String(a.url).trim() : undefined
          }))
          .filter(a => a.name && (a.content || a.url))
      : [];

    console.log('[sendBulkEmail] Invocation started:', {
      businessId: bizId,
      selected_contact_ids,
      subject,
      attachmentsCount: validAttachments.length
    });

    if (!subject || !subject.trim()) {
      return res.status(400).json({ success: false, message: 'Subject is required' });
    }
    if (!body || !body.trim()) {
      return res.status(400).json({ success: false, message: 'Message body is required' });
    }

    let { where, params } = buildContactFilterWhere(bizId, req.user, { channel, status, tag, search, agent, transferred_only });

    if (Array.isArray(selected_contact_ids) && selected_contact_ids.length > 0) {
      where += ` AND c.id IN (${selected_contact_ids.map(() => '?').join(',')})`;
      params.push(...selected_contact_ids.map(id => Number(id)));
    }

    const [rows] = await pool.query(`
      SELECT c.id, c.name, c.email, c.phone, c.status_name
      FROM contacts c
      ${where}
      ORDER BY c.id DESC
    `, params);

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const validRecipients = [];
    const skippedMissing = [];
    const skippedInvalid = [];

    rows.forEach(c => {
      const em = c.email ? String(c.email).trim() : '';
      if (!em) {
        skippedMissing.push({ id: c.id, name: c.name || 'Unnamed Lead', phone: c.phone });
      } else if (!emailRegex.test(em)) {
        skippedInvalid.push({ id: c.id, name: c.name || 'Unnamed Lead', email: em, phone: c.phone });
      } else {
        validRecipients.push({
          id: c.id,
          name: c.name || 'Valued Customer',
          email: em,
          phone: c.phone
        });
      }
    });

    console.log(`[sendBulkEmail] Total matched contacts: ${rows.length}. validRecipients.length: ${validRecipients.length}, skippedMissing: ${skippedMissing.length}, skippedInvalid: ${skippedInvalid.length}`);

    if (validRecipients.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid email recipients found matching the selected filters/leads.',
        data: {
          skippedMissing,
          skippedInvalid
        }
      });
    }

    const campaignId = `CAMP-${Date.now()}`;
    const sender = brevoService.getSender();
    let sentCount = 0;
    let failedCount = 0;
    const sendResults = [];

    for (const recipient of validRecipients) {
      if (recipient.email.toLowerCase() === sender.email.toLowerCase()) {
        console.warn(`[sendBulkEmail] WARNING: Lead email ${recipient.email} is identical to BREVO_SENDER_EMAIL ${sender.email}. Proceeding with send.`);
      }

      const firstName = (recipient.name || '').split(' ')[0] || 'there';
      const personalizedSubject = subject
        .replace(/\{\{first_name\}\}/gi, firstName)
        .replace(/\{\{name\}\}/gi, recipient.name);

      const personalizedBody = body
        .replace(/\{\{first_name\}\}/gi, firstName)
        .replace(/\{\{name\}\}/gi, recipient.name);

      let initialStatus = 'queued'; // Status is 'queued' until Brevo confirms delivery via webhook or polling
      let brevoMsgId = null;
      let failureReason = null;

      try {
        console.log(`[sendBulkEmail] Sending email to contact ${recipient.id} (${recipient.email}) from ${sender.email}...`);
        const brevoRes = await brevoService.sendEmail({
          toEmail: recipient.email,
          toName: recipient.name,
          subject: personalizedSubject,
          htmlContent: personalizedBody.replace(/\n/g, '<br/>'),
          textContent: personalizedBody,
          attachment: validAttachments.length > 0 ? validAttachments : undefined
        });
        // Normalize messageId by trimming angle brackets < >
        brevoMsgId = brevoRes.messageId ? brevoRes.messageId.replace(/[<>]/g, '').trim() : null;
        console.log(`[sendBulkEmail] Brevo accepted email for contact ${recipient.id} (${recipient.email}), messageId: ${brevoMsgId}`);
        sentCount++;
      } catch (sendErr) {
        initialStatus = 'failed';
        failureReason = sendErr.message;
        failedCount++;
        console.error(`[sendBulkEmail] Failed sending to contact ${recipient.id} (${recipient.email}):`, sendErr.message);
      }

      // Save email record into lead_emails linked to student/lead
      try {
        const attachmentNote = validAttachments.length > 0
          ? `\n\n📎 Attachments (${validAttachments.length}): ` + validAttachments.map(a => a.name).join(', ')
          : '';
        const savedContent = personalizedBody + attachmentNote;

        const [insertRes] = await pool.query(`
          INSERT INTO lead_emails (
            business_id, contact_id, campaign_id, brevo_message_id, 
            sender_email, to_email, subject, content, status, bounce_reason, sent_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        `, [
          bizId,
          recipient.id,
          campaignId,
          brevoMsgId,
          sender.email,
          recipient.email,
          personalizedSubject,
          savedContent,
          initialStatus,
          failureReason
        ]);
        console.log(`[sendBulkEmail] Inserted into lead_emails for contact ${recipient.id} (id: ${insertRes.insertId}, status: ${initialStatus}, brevo_id: ${brevoMsgId})`);
      } catch (dbErr) {
        console.error(`[sendBulkEmail] FATAL: Error inserting into lead_emails for contact ${recipient.id}:`, dbErr);
      }

      sendResults.push({
        contactId: recipient.id,
        name: recipient.name,
        email: recipient.email,
        status: initialStatus,
        messageId: brevoMsgId,
        error: failureReason
      });
    }

    const isSuccess = sentCount > 0;
    return res.json({
      success: isSuccess,
      message: isSuccess
        ? 'Email sent successfully'
        : `Email delivery failed: ${sendResults[0]?.error || 'Unable to deliver emails.'}`,
      data: {
        campaignId,
        totalRecipients: validRecipients.length,
        sentCount,
        failedCount,
        skippedMissing,
        skippedInvalid,
        results: sendResults
      }
    });

  } catch (err) {
    console.error('[sendBulkEmail] error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

/**
 * Fallback Refresh Endpoint: Poll Brevo directly for delivery statuses
 * POST /api/contacts/email-status/refresh { campaign_id }
 */
const refreshEmailStatus = async (req, res) => {
  try {
    const bizId = req.user.businessId;
    const { campaign_id } = req.body;

    if (!campaign_id) {
      return res.status(400).json({ success: false, message: 'campaign_id is required' });
    }

    const [rows] = await pool.query(`
      SELECT le.*, c.name as contact_name 
      FROM lead_emails le
      LEFT JOIN contacts c ON le.contact_id = c.id
      WHERE le.campaign_id = ? AND le.business_id = ?
    `, [campaign_id, bizId]);

    if (rows.length === 0) {
      return res.json({ success: true, data: { updatedRows: [] } });
    }

    const updatedRows = [];

    for (const record of rows) {
      // Check if candidate for refresh (still in queued or deferred)
      if (record.brevo_message_id && (record.status === 'queued' || record.status === 'deferred')) {
        const eventsData = await brevoService.getEmailEventsByMessageId(record.brevo_message_id);

        if (eventsData && Array.isArray(eventsData.events) && eventsData.events.length > 0) {
          // Sort events by date ascending
          const sortedEvents = eventsData.events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
          
          let resolvedStatus = record.status;
          let bounceReason = record.bounce_reason;
          let deliveredAt = record.delivered_at;
          let openedAt = record.opened_at;
          let clickedAt = record.clicked_at;
          let lastEvent = record.last_event;

          for (const ev of sortedEvents) {
            const evName = (ev.name || '').toLowerCase();
            lastEvent = evName;
            if (evName === 'delivered') {
              resolvedStatus = 'delivered';
              deliveredAt = ev.date ? new Date(ev.date) : new Date();
            } else if (evName === 'opened' || evName === 'unique_opened') {
              resolvedStatus = 'opened';
              openedAt = ev.date ? new Date(ev.date) : new Date();
            } else if (evName === 'clicks') {
              resolvedStatus = 'clicked';
              clickedAt = ev.date ? new Date(ev.date) : new Date();
            } else if (evName === 'soft_bounces') {
              resolvedStatus = 'soft_bounce';
              bounceReason = ev.reason || 'Soft bounce';
            } else if (evName === 'hard_bounces') {
              resolvedStatus = 'hard_bounce';
              bounceReason = ev.reason || 'Hard bounce';
            } else if (evName === 'blocked') {
              resolvedStatus = 'blocked';
              bounceReason = ev.reason || 'Mailbox or domain blocked';
            } else if (evName === 'spam') {
              resolvedStatus = 'spam';
              bounceReason = 'Marked as spam';
            } else if (evName === 'invalid_email') {
              resolvedStatus = 'invalid_email';
              bounceReason = 'Invalid email address';
            } else if (evName === 'deferred') {
              resolvedStatus = 'deferred';
              bounceReason = ev.reason || 'Deferred by recipient server';
            }
          }

          if (resolvedStatus !== record.status || bounceReason !== record.bounce_reason) {
            await pool.query(`
              UPDATE lead_emails
              SET status = ?,
                  bounce_reason = ?,
                  delivered_at = ?,
                  opened_at = ?,
                  clicked_at = ?,
                  last_event = ?,
                  last_event_at = NOW(),
                  updated_at = NOW()
              WHERE id = ?
            `, [resolvedStatus, bounceReason, deliveredAt, openedAt, clickedAt, lastEvent, record.id]);

            record.status = resolvedStatus;
            record.bounce_reason = bounceReason;
            record.delivered_at = deliveredAt;
            record.opened_at = openedAt;
            record.clicked_at = clickedAt;
            record.last_event = lastEvent;
          }
        }
      }

      updatedRows.push({
        id: record.id,
        contactId: record.contact_id,
        name: record.contact_name || 'Valued Customer',
        email: record.to_email,
        status: record.status,
        reason: record.bounce_reason,
        deliveredAt: record.delivered_at,
        openedAt: record.opened_at,
        sentAt: record.sent_at
      });
    }

    return res.json({
      success: true,
      data: {
        updatedRows
      }
    });

  } catch (err) {
    console.error('[refreshEmailStatus] error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};


const bulkTransferContacts = async (req, res) => {
  let conn;
  try {
    const bizId = req.user.businessId;
    const userId = req.user.userId || req.user.id;
    const userRole = (req.user.role || 'agent').toLowerCase().trim();

    // Permission check: Admins and Team Leaders (users with assigned team members) only
    const isAdmin = userRole === 'admin' || userRole === 'superadmin' || Boolean(req.user.is_dev);
    const accessibleUserIds = await getAccessibleUserIds(req.user, bizId);

    if (!isAdmin) {
      if (!accessibleUserIds || accessibleUserIds.length <= 1) {
        return res.status(403).json({ 
          success: false, 
          message: 'Permission denied: Lead transfer is restricted to Admins and Team Leaders with assigned team members.' 
        });
      }
    }

    const {
      contact_ids,
      from_agent_id,
      status_id,
      target_agent_id,
      allocations,
      branch_id,
      branch_name,
      department_id,
      department_name,
      new_status_id,
      new_status_name,
      remarks
    } = req.body;

    const hasSingleTarget = target_agent_id !== undefined && target_agent_id !== null && target_agent_id !== '';
    const hasAllocations = Array.isArray(allocations) && allocations.length > 0 && allocations.some(a => a.userId && (a.count > 0 || allocations.length > 0));

    if (!hasSingleTarget && !hasAllocations) {
      return res.status(400).json({ success: false, message: 'Please select a destination employee to transfer leads to.' });
    }

    conn = await pool.getConnection();

    let byUserName = req.user.name || 'System';
    const [currentUserRows] = await conn.query('SELECT name FROM users WHERE id = ?', [userId]);
    if (currentUserRows.length > 0 && currentUserRows[0].name) {
      byUserName = currentUserRows[0].name;
    }

    let targetContacts = [];

    if (Array.isArray(contact_ids) && contact_ids.length > 0) {
      let query = `
        SELECT c.id, c.name, c.phone, c.assigned_to, c.branch_id, c.branch_name, c.department_id, c.department_name, c.status_id, c.status_name, c.user_list
        FROM contacts c
        WHERE c.business_id = ? AND c.id IN (${contact_ids.map(() => '?').join(',')})
      `;
      let params = [bizId, ...contact_ids];

      if (!isAdmin && accessibleUserIds !== null) {
        query += ` AND c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')})`;
        params.push(...accessibleUserIds);
      }

      const [rows] = await conn.query(query, params);
      targetContacts = rows;
    } else if (from_agent_id !== undefined && from_agent_id !== null) {
      let query = `
        SELECT c.id, c.name, c.phone, c.assigned_to, c.branch_id, c.branch_name, c.department_id, c.department_name, c.status_id, c.status_name, c.user_list
        FROM contacts c
        WHERE c.business_id = ?
      `;
      let params = [bizId];

      if (!isAdmin && accessibleUserIds !== null) {
        query += ` AND c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')})`;
        params.push(...accessibleUserIds);
      } else if (from_agent_id === 'unassigned') {
        query += ' AND (c.assigned_to IS NULL OR c.assigned_to = 0)';
      } else if (from_agent_id !== 'all') {
        query += ' AND c.assigned_to = ?';
        params.push(from_agent_id);
      }

      const filterStatus = req.body.from_status_id || status_id;
      if (filterStatus && filterStatus !== 'all') {
        query += ' AND c.status_id = ?';
        params.push(filterStatus);
      }

      const filterBranch = req.body.from_branch_id || (from_agent_id !== undefined ? branch_id : null);
      if (filterBranch && filterBranch !== 'all') {
        query += ' AND c.branch_id = ?';
        params.push(filterBranch);
      }

      const [rows] = await conn.query(query, params);
      targetContacts = rows;
    }

    if (!targetContacts || targetContacts.length === 0) {
      conn.release();
      return res.status(400).json({ success: false, message: 'No matching leads found to transfer.' });
    }

    const assignmentPlan = [];
    const userNamesMap = new Map();

    const targetUserIds = new Set();
    if (hasSingleTarget) targetUserIds.add(Number(target_agent_id));
    if (hasAllocations) {
      allocations.forEach(a => { if (a.userId) targetUserIds.add(Number(a.userId)); });
    }

    if (targetUserIds.size > 0) {
      const [uRows] = await conn.query(
        `SELECT id, name FROM users WHERE id IN (${Array.from(targetUserIds).map(() => '?').join(',')})`,
        Array.from(targetUserIds)
      );
      uRows.forEach(u => userNamesMap.set(u.id, u.name));
    }

    if (hasAllocations) {
      let contactIndex = 0;
      const validAllocs = allocations.filter(a => a.userId && (a.count > 0 || allocations.length > 0));
      
      for (const alloc of validAllocs) {
        const uId = Number(alloc.userId);
        const uName = userNamesMap.get(uId) || 'Assigned Agent';
        const allocCount = alloc.count && alloc.count > 0 ? Number(alloc.count) : Math.ceil(targetContacts.length / validAllocs.length);
        
        for (let i = 0; i < allocCount && contactIndex < targetContacts.length; i++) {
          assignmentPlan.push({
            contact: targetContacts[contactIndex],
            targetUserId: uId,
            targetUserName: uName
          });
          contactIndex++;
        }
      }

      while (contactIndex < targetContacts.length) {
        const alloc = validAllocs[contactIndex % validAllocs.length];
        const uId = Number(alloc.userId);
        assignmentPlan.push({
          contact: targetContacts[contactIndex],
          targetUserId: uId,
          targetUserName: userNamesMap.get(uId) || 'Assigned Agent'
        });
        contactIndex++;
      }
    } else {
      const uId = Number(target_agent_id);
      const uName = userNamesMap.get(uId) || 'Assigned Agent';
      for (const contact of targetContacts) {
        assignmentPlan.push({
          contact,
          targetUserId: uId,
          targetUserName: uName
        });
      }
    }

    await conn.beginTransaction();

    const transferRemarks = remarks && remarks.trim() 
      ? remarks.trim() 
      : `Bulk lead transfer by ${byUserName}`;

    const resolvedBranchId = (branch_id !== undefined && branch_id !== null && branch_id !== '') ? Number(branch_id) : null;
    const resolvedBranchName = resolvedBranchId ? (branch_name || null) : null;

    const resolvedDeptId = (department_id !== undefined && department_id !== null && department_id !== '') ? Number(department_id) : null;
    const resolvedDeptName = resolvedDeptId ? (department_name || null) : null;

    const resolvedStatusId = (new_status_id !== undefined && new_status_id !== null && new_status_id !== '') ? Number(new_status_id) : null;
    let resolvedStatusName = resolvedStatusId ? (new_status_name || null) : null;
    let resolvedStatusType = null;

    if (resolvedStatusId !== null) {
      const [stRows] = await conn.query('SELECT name, type FROM statuses WHERE id = ?', [resolvedStatusId]);
      if (stRows.length > 0) {
        resolvedStatusType = stRows[0].type || null;
        if (!resolvedStatusName) {
          resolvedStatusName = stRows[0].name;
        }
      }
    }

    const notificationCounts = new Map();

    for (const item of assignmentPlan) {
      const { contact, targetUserId, targetUserName } = item;
      const contactId = contact.id;

      const finalBranchId = resolvedBranchId !== null ? resolvedBranchId : (contact.branch_id || null);
      const finalBranchName = resolvedBranchId !== null ? resolvedBranchName : (contact.branch_name || null);

      const finalDeptId = resolvedDeptId !== null ? resolvedDeptId : (contact.department_id || null);
      const finalDeptName = resolvedDeptId !== null ? resolvedDeptName : (contact.department_name || null);

      const finalStatusId = resolvedStatusId !== null ? resolvedStatusId : (contact.status_id || null);
      const finalStatusName = resolvedStatusId !== null ? resolvedStatusName : (contact.status_name || null);

      await conn.query(
        `INSERT INTO follow_ups (
          contact_id, contact_name, follow_up_date, by_user_id, by_user_name,
          to_user_id, to_user_name, status_id, status_name,
          branch_id, branch_name, department_id, department_name, remarks
        ) VALUES (?, ?, CURDATE(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          contactId,
          contact.name || contact.phone || 'Lead',
          userId,
          byUserName,
          targetUserId,
          targetUserName,
          finalStatusId,
          finalStatusName,
          finalBranchId,
          finalBranchName,
          finalDeptId,
          finalDeptName,
          transferRemarks
        ]
      );

      let currentList = contact.user_list ? (typeof contact.user_list === 'string' ? JSON.parse(contact.user_list) : contact.user_list) : [];
      if (!Array.isArray(currentList)) currentList = [];
      if (contact.assigned_to && !currentList.includes(contact.assigned_to) && !currentList.includes(String(contact.assigned_to)) && !currentList.includes(Number(contact.assigned_to))) {
        currentList.push(contact.assigned_to);
      }
      if (targetUserId && !currentList.includes(targetUserId) && !currentList.includes(String(targetUserId)) && !currentList.includes(Number(targetUserId))) {
        currentList.push(targetUserId);
      }

      const updateFields = ['assigned_to = ?', 'user_list = ?', 'follow_up_count = COALESCE(follow_up_count, 0) + 1'];
      const updateParams = [targetUserId, JSON.stringify(currentList)];

      if (resolvedBranchId !== null) {
        updateFields.push('branch_id = ?', 'branch_name = ?');
        updateParams.push(resolvedBranchId, resolvedBranchName);
      }
      if (resolvedDeptId !== null) {
        updateFields.push('department_id = ?', 'department_name = ?');
        updateParams.push(resolvedDeptId, resolvedDeptName);
      }
      if (resolvedStatusId !== null) {
        updateFields.push('status_id = ?', 'status_name = ?');
        updateParams.push(resolvedStatusId, resolvedStatusName);

        const now = new Date();
        if (resolvedStatusType === 'sale') {
          updateFields.push('current_sale_status = ?', 'sale_won = ?', 'sale_won_date = ?', 'sale_won_by = ?', 'sale_lost = ?', 'sale_lost_date = ?', 'sale_lost_by = ?');
          updateParams.push(1, 1, now, targetUserId, 0, null, null);
        } else if (resolvedStatusType === 'sale_lost') {
          updateFields.push('current_sale_status = ?', 'sale_won = ?', 'sale_won_date = ?', 'sale_won_by = ?', 'sale_lost = ?', 'sale_lost_date = ?', 'sale_lost_by = ?');
          updateParams.push(2, 0, null, null, 1, now, targetUserId);
        } else {
          updateFields.push('current_sale_status = ?', 'sale_won = ?', 'sale_won_date = ?', 'sale_won_by = ?', 'sale_lost = ?', 'sale_lost_date = ?', 'sale_lost_by = ?');
          updateParams.push(0, 0, null, null, 0, null, null);
        }
      }

      updateParams.push(contactId, bizId);
      await conn.query(
        `UPDATE contacts SET ${updateFields.join(', ')} WHERE id = ? AND business_id = ?`,
        updateParams
      );

      await conn.query(
        'UPDATE conversations SET assigned_to = ? WHERE contact_id = ? AND business_id = ?',
        [targetUserId, contactId, bizId]
      );

      await conn.query(
        'INSERT INTO contact_history (contact_id, business_id, user_id, field_name, old_value, new_value) VALUES (?, ?, ?, ?, ?, ?)',
        [contactId, bizId, userId, 'assigned_to', contact.assigned_to ? String(contact.assigned_to) : 'Unassigned', String(targetUserId)]
      );

      if (resolvedStatusId !== null && resolvedStatusId !== contact.status_id) {
        await conn.query(
          'INSERT INTO contact_history (contact_id, business_id, user_id, field_name, old_value, new_value) VALUES (?, ?, ?, ?, ?, ?)',
          [contactId, bizId, userId, 'status_id', contact.status_name || (contact.status_id ? String(contact.status_id) : 'None'), resolvedStatusName || String(resolvedStatusId)]
        );
      }

      notificationCounts.set(targetUserId, (notificationCounts.get(targetUserId) || 0) + 1);
    }

    await conn.commit();

    const io = req.app && typeof req.app.get === 'function' ? req.app.get('io') : null;
    for (const [tUserId, count] of notificationCounts.entries()) {
      await pool.query(
        `INSERT INTO notifications (business_id, user_id, type, title, message, reference_id)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [bizId, tUserId, 'assignment', 'Bulk Leads Transferred', `${count} lead(s) have been transferred to you by ${byUserName}.`, targetContacts[0].id]
      );
      if (io) {
        io.to(`biz_${bizId}`).emit('contacts_bulk_transferred', {
          count,
          assigned_to: tUserId,
          transferred_by: byUserName
        });
      }
    }

    res.json({
      success: true,
      count: targetContacts.length,
      message: `Successfully transferred ${targetContacts.length} lead(s).`
    });

  } catch (err) {
    if (conn) await conn.rollback();
    console.error('[bulkTransferContacts] error:', err);
    res.status(500).json({ success: false, message: err.message });
  } finally {
    if (conn) conn.release();
  }
};

const getTotalLeads = async (req, res) => {
  try {
    const { 
      page, 
      limit, 
      search, 
      status, 
      agent, 
      has_followup, 
      has_payment,
      sortBy = 'created_at',
      sortOrder = 'DESC'
    } = req.query;

    const { offset, limit: lim, page: p } = paginate(page, limit);
    const bizId = req.user.businessId || req.user.business_id || 1;

    let where = 'WHERE c.business_id = ?';
    const params = [bizId];

    // Hierarchy / Accessibility scope
    const accessibleUserIds = await getAccessibleUserIds(req.user, bizId);
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        where += ' AND 1 = 0 ';
      } else if (agent === 'unassigned') {
        where += ' AND (c.assigned_to IS NULL OR c.assigned_to = 0) ';
      } else if (agent) {
        const reqAgentId = Number(agent);
        if (accessibleUserIds.includes(reqAgentId)) {
          where += ' AND c.assigned_to = ? ';
          params.push(reqAgentId);
        } else {
          where += ' AND 1 = 0 ';
        }
      } else {
        where += ` AND c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')})`;
        params.push(...accessibleUserIds);
      }
    } else {
      // Admin / Superadmin
      if (agent === 'unassigned') {
        where += ' AND (c.assigned_to IS NULL OR c.assigned_to = 0)';
      } else if (agent) {
        where += ' AND c.assigned_to = ?';
        params.push(agent);
      }
    }

    // Status filter
    if (status === 'none' || status === 'no_status') {
      where += ' AND (c.status_name IS NULL OR TRIM(c.status_name) = "")';
    } else if (status) {
      const sLower = status.trim().toLowerCase();
      if (sLower === 'status is not follow up' || sLower === 'not follow up' || sLower === 'no follow up' || sLower === 'no_followup' || sLower === 'no date') {
        where += ' AND c.follow_up_date IS NULL';
      } else {
        where += ' AND c.status_name = ?';
        params.push(status);
      }
    }

    // Follow-up date filter
    if (has_followup === '1' || has_followup === 'true') {
      where += ' AND c.follow_up_date IS NOT NULL';
    } else if (has_followup === '0' || has_followup === 'false') {
      where += ' AND c.follow_up_date IS NULL';
    }

    // Payment / Receipts filter
    if (has_payment === '1' || has_payment === 'true') {
      where += ' AND EXISTS (SELECT 1 FROM receipts r WHERE r.contact_id = c.id AND r.amount > 0)';
    } else if (has_payment === '0' || has_payment === 'false') {
      where += ' AND NOT EXISTS (SELECT 1 FROM receipts r WHERE r.contact_id = c.id AND r.amount > 0)';
    }

    // Search filter
    if (search && search.trim()) {
      where += ' AND (c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?)';
      const s = `%${search.trim()}%`;
      params.push(s, s, s);
    }

    // Metrics / summary counts
    const [[counts]] = await pool.query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN c.follow_up_date IS NOT NULL THEN 1 END) as with_followup,
        COUNT(CASE WHEN c.follow_up_date IS NULL THEN 1 END) as without_followup,
        COUNT(CASE WHEN c.assigned_to IS NULL OR c.assigned_to = 0 THEN 1 END) as unassigned_count,
        COUNT(CASE WHEN c.status_name IS NULL OR TRIM(c.status_name) = '' THEN 1 END) as no_status_count,
        COUNT(CASE WHEN EXISTS (SELECT 1 FROM receipts r WHERE r.contact_id = c.id AND r.amount > 0) THEN 1 END) as with_payment_count,
        COALESCE(SUM((SELECT SUM(r.amount) FROM receipts r WHERE r.contact_id = c.id)), 0) as total_payment_collected
      FROM contacts c ${where}
    `, params);

    // Paginated leads with payment and assignment details
    const [rows] = await pool.query(`
      SELECT 
        c.*,
        u.name as assigned_employee_name,
        e.name as enquiry_for_name,
        (SELECT remarks FROM follow_ups WHERE contact_id = c.id ORDER BY follow_up_id DESC LIMIT 1) as latest_remark,
        COALESCE((SELECT SUM(r.amount) FROM receipts r WHERE r.contact_id = c.id), 0) as total_payment_amount,
        (SELECT COUNT(*) FROM receipts r WHERE r.contact_id = c.id) as payment_count,
        (SELECT r.receipt_type_name FROM receipts r WHERE r.contact_id = c.id ORDER BY r.receipt_date DESC, r.id DESC LIMIT 1) as latest_payment_type,
        (SELECT r.receipt_date FROM receipts r WHERE r.contact_id = c.id ORDER BY r.receipt_date DESC, r.id DESC LIMIT 1) as latest_payment_date
      FROM contacts c
      LEFT JOIN users u ON c.assigned_to = u.id
      LEFT JOIN enquiry_fors e ON c.enquiry_for_id = e.id
      ${where}
      ORDER BY c.created_at DESC, c.id DESC
      LIMIT ? OFFSET ?
    `, [...params, lim, offset]);

    res.json({
      success: true,
      data: rows,
      total: counts?.total || 0,
      page: p,
      limit: lim,
      totalPages: Math.max(1, Math.ceil((counts?.total || 0) / lim)),
      metrics: {
        total: counts?.total || 0,
        with_followup: counts?.with_followup || 0,
        without_followup: counts?.without_followup || 0,
        unassigned: counts?.unassigned_count || 0,
        no_status: counts?.no_status_count || 0,
        with_payment: counts?.with_payment_count || 0,
        total_payment_collected: Number(counts?.total_payment_collected || 0)
      }
    });
  } catch (err) {
    console.error('[getTotalLeads] error:', err);
    res.status(500).json({ success: false, message: err.message, data: [] });
  }
};

module.exports = { 
  getContacts, 
  getTotalLeads,
  getContact, 
  createContact, 
  updateContact, 
  deleteContact, 
  importContacts, 
  exportContacts, 
  optIn, 
  optOut, 
  createOptInLink, 
  handleOptInLink, 
  getUniqueTags, 
  getContactHistory, 
  getContactDocuments, 
  uploadContactDocument, 
  deleteContactDocument,
  importExcelContacts,
  previewBulkEmail,
  sendBulkEmail,
  refreshEmailStatus,
  bulkTransferContacts
};

