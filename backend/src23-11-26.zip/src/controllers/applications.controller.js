const pool = require('../db/pool');
const { getAccessibleUserIds } = require('../services/teamHierarchy.service');

const getApplications = async (req, res) => {
  try {
    const { contactId } = req.params;
    const businessId = req.user.businessId;
    const accessibleUserIds = await getAccessibleUserIds(req.user, businessId);

    let scopeClause = '';
    const params = [contactId, businessId];
    if (accessibleUserIds !== null) {
      if (accessibleUserIds.length === 0) {
        return res.json({ success: true, data: [], message: 'OK' });
      }
      scopeClause = ` AND (c.assigned_to IN (${accessibleUserIds.map(() => '?').join(',')}) OR a.created_by IN (${accessibleUserIds.map(() => '?').join(',')})) `;
      params.push(...accessibleUserIds, ...accessibleUserIds);
    }

    const [rows] = await pool.query(`
      SELECT a.*, 
             i.name as intake_name, 
             y.name as year_name, 
             s.name as status_name, s.color as status_color
      FROM applications a
      LEFT JOIN contacts c ON a.contact_id = c.id
      LEFT JOIN intakes i ON a.intake_id = i.id
      LEFT JOIN years y ON a.year_id = y.id
      LEFT JOIN application_statuses s ON a.status_id = s.id
      WHERE a.contact_id = ? AND a.business_id = ? ${scopeClause}
      ORDER BY a.created_at DESC
    `, params);
    res.json({ success: true, data: rows, message: 'OK' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const createApplication = async (req, res) => {
  try {
    const { contact_id, country, university, course, intake_id, year_id, status_id, description } = req.body;
    
    

    const [result] = await pool.query(
      'INSERT INTO applications (contact_id, business_id, country, university, course, intake_id, year_id, status_id, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [contact_id, req.user.businessId, country || 'New Zealand', university, course, intake_id || null, year_id || null, status_id || null, description]
    );
    
    // Log history
    await pool.query(
      'INSERT INTO application_history (application_id, changed_by, action, details) VALUES (?, ?, ?, ?)',
      [result.insertId, req.user.id, 'Application Created', 'Initial application created.']
    );

    // Record initial status in application_status_change if status is assigned
    if (status_id) {
      const [stRows] = await pool.query('SELECT name FROM application_statuses WHERE id=?', [status_id]);
      const statusName = stRows.length > 0 ? stRows[0].name : null;
      await pool.query(
        'INSERT INTO application_status_change (application_id, status_change_date, old_status_id, old_status_name, new_status_id, new_status_name, changed_by) VALUES (?, NOW(), NULL, NULL, ?, ?, ?)',
        [result.insertId, status_id, statusName, req.user.id]
      );
    }

    const [rows] = await pool.query('SELECT * FROM applications WHERE id=?', [result.insertId]);
    res.status(201).json({ success: true, data: rows[0], message: 'Application created' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const updateApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const { country, university, course, intake_id, year_id, status_id, description } = req.body;
    
    // Get old data for history
    const [oldRows] = await pool.query(`
      SELECT a.*, i.name as intake_name, y.name as year_name, s.name as status_name
      FROM applications a
      LEFT JOIN intakes i ON a.intake_id = i.id
      LEFT JOIN years y ON a.year_id = y.id
      LEFT JOIN application_statuses s ON a.status_id = s.id
      WHERE a.id=? AND a.business_id=?
    `, [id, req.user.businessId]);
    if (oldRows.length === 0) return res.status(404).json({ success: false, message: 'Application not found' });
    const oldApp = oldRows[0];

    await pool.query(
      'UPDATE applications SET country=?, university=?, course=?, intake_id=?, year_id=?, status_id=?, description=? WHERE id=? AND business_id=?',
      [country || 'New Zealand', university, course, intake_id || null, year_id || null, status_id || null, description, id, req.user.businessId]
    );

    // Get new data for history comparisons
    const [newRows] = await pool.query(`
      SELECT a.*, i.name as intake_name, y.name as year_name, s.name as status_name
      FROM applications a
      LEFT JOIN intakes i ON a.intake_id = i.id
      LEFT JOIN years y ON a.year_id = y.id
      LEFT JOIN application_statuses s ON a.status_id = s.id
      WHERE a.id=? AND a.business_id=?
    `, [id, req.user.businessId]);
    const newApp = newRows[0];

    // Record status change into application_status_change only if status has changed
    const oldStatusId = oldApp.status_id ? Number(oldApp.status_id) : null;
    const newStatusId = newApp.status_id ? Number(newApp.status_id) : null;
    if (oldStatusId !== newStatusId) {
      await pool.query(
        'INSERT INTO application_status_change (application_id, status_change_date, old_status_id, old_status_name, new_status_id, new_status_name, changed_by) VALUES (?, NOW(), ?, ?, ?, ?, ?)',
        [id, oldStatusId, oldApp.status_name || null, newStatusId, newApp.status_name || null, req.user.id]
      );
    }

    // Determine what changed
    let changes = [];
    if (oldApp.country !== newApp.country) changes.push(`Country changed from '${oldApp.country || 'None'}' to '${newApp.country || 'None'}'`);
    if (oldApp.university !== newApp.university) changes.push(`University changed from '${oldApp.university || 'None'}' to '${newApp.university || 'None'}'`);
    if (oldApp.course !== newApp.course) changes.push(`Course changed from '${oldApp.course || 'None'}' to '${newApp.course || 'None'}'`);
    if (oldApp.status_name !== newApp.status_name) changes.push(`Status changed from '${oldApp.status_name || 'None'}' to '${newApp.status_name || 'None'}'`);
    if (oldApp.intake_name !== newApp.intake_name) changes.push(`Intake changed from '${oldApp.intake_name || 'None'}' to '${newApp.intake_name || 'None'}'`);
    if (oldApp.year_name !== newApp.year_name) changes.push(`Year changed from '${oldApp.year_name || 'None'}' to '${newApp.year_name || 'None'}'`);
    
    const details = changes.length > 0 ? changes.join(', ') : 'Application updated.';

    // Log history if there are changes
    if (changes.length > 0) {
      await pool.query(
        'INSERT INTO application_history (application_id, changed_by, action, details) VALUES (?, ?, ?, ?)',
        [id, req.user.id, 'Application Updated', details]
      );
    }

    const [rows] = await pool.query(`
      SELECT a.*, i.name as intake_name, y.name as year_name, s.name as status_name, s.color as status_color
      FROM applications a
      LEFT JOIN intakes i ON a.intake_id = i.id
      LEFT JOIN years y ON a.year_id = y.id
      LEFT JOIN application_statuses s ON a.status_id = s.id
      WHERE a.id=?
    `, [id]);
    res.json({ success: true, data: rows[0], message: 'Application updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const deleteApplication = async (req, res) => {
  try {
    await pool.query('DELETE FROM applications WHERE id=? AND business_id=?', [req.params.id, req.user.businessId]);
    res.json({ success: true, data: null, message: 'Application deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

const getApplicationHistory = async (req, res) => {
  try {
    const { applicationId } = req.params;
    const [rows] = await pool.query(`
      SELECT h.*, u.name as user_name 
      FROM application_history h
      LEFT JOIN users u ON h.changed_by = u.id
      WHERE h.application_id = ?
      ORDER BY h.created_at DESC
    `, [applicationId]);
    res.json({ success: true, data: rows, message: 'OK' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message, data: null });
  }
};

module.exports = {
  getApplications,
  createApplication,
  updateApplication,
  deleteApplication,
  getApplicationHistory
};
