/**
 * Brevo Transactional Email Service
 * Uses native fetch (Node.js 18+) to avoid OpenSSL SSL3 record MAC decryption
 * issues on Windows environments when communicating with Brevo Cloudflare endpoints.
 */
class BrevoService {
  constructor() {
    this.apiUrl = 'https://api.brevo.com/v3/smtp/email';
    this.smtpEmailsUrl = 'https://api.brevo.com/v3/smtp/emails';
  }

  getApiKey() {
    return (process.env.BREVO_API_KEY || '').trim();
  }

  getSender() {
    return {
      email: (process.env.BREVO_SENDER_EMAIL || 'sreelakshmichoicecampaigns8@gmail.com').trim(),
      name: (process.env.BREVO_SENDER_NAME || 'choicecampaigns').trim()
    };
  }

  /**
   * Send a single transactional email via Brevo v3 API
   * @param {Object} options
   * @param {string} options.toEmail
   * @param {string} [options.toName]
   * @param {string} options.subject
   * @param {string} options.htmlContent
   * @param {string} [options.textContent]
   * @param {Object} [options.params]
   * @param {Array<{ name: string, content?: string, url?: string }>} [options.attachment]
   * @returns {Promise<{ messageId: string }>}
   */
  async sendEmail({ toEmail, toName, subject, htmlContent, textContent, params, attachment }) {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new Error('BREVO_API_KEY is not configured in environment variables');
    }

    const sender = this.getSender();
    const payload = {
      sender: {
        name: sender.name,
        email: sender.email
      },
      to: [
        {
          email: toEmail.trim(),
          name: toName ? toName.trim() : undefined
        }
      ],
      subject: subject,
      htmlContent: htmlContent || (textContent ? textContent.replace(/\n/g, '<br/>') : '<p></p>')
    };

    if (params && typeof params === 'object' && Object.keys(params).length > 0) {
      payload.params = params;
    }

    if (textContent) {
      payload.textContent = textContent;
    }

    if (Array.isArray(attachment) && attachment.length > 0) {
      const validAttachments = attachment
        .map(att => {
          const item = {
            name: att.name || 'attachment'
          };
          if (att.content) {
            // Strip any data URI scheme e.g. "data:application/pdf;base64,"
            item.content = String(att.content).replace(/^data:[^;]+;base64,/, '').trim();
          } else if (att.url) {
            item.url = att.url;
          }
          return item;
        })
        .filter(item => (item.content || item.url) && item.name);

      if (validAttachments.length > 0) {
        payload.attachment = validAttachments;
        console.log(`[BrevoService.sendEmail] Sending email with ${validAttachments.length} attachment(s):`,
          validAttachments.map(a => ({ name: a.name, hasContent: !!a.content, url: a.url }))
        );
      }
    }

    try {
      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'api-key': apiKey,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const responseBody = await response.json();

      if (!response.ok) {
        console.error('[BrevoService.sendEmail] API Error Response:', response.status, responseBody);
        const errMessage = responseBody.message || JSON.stringify(responseBody) || `Brevo returned HTTP ${response.status}`;
        const err = new Error(errMessage);
        err.status = response.status;
        err.brevoData = responseBody;
        throw err;
      }

      console.log('[BrevoService.sendEmail] Brevo Response:', response.status, responseBody);

      return {
        messageId: responseBody.messageId || null
      };
    } catch (error) {
      console.error('[BrevoService.sendEmail] Request failure:', error.message);
      throw error;
    }
  }

  /**
   * Query Brevo for transactional email status events by messageId
   * GET https://api.brevo.com/v3/smtp/emails?messageId=<id>
   * @param {string} messageId
   */
  async getEmailEventsByMessageId(messageId) {
    const apiKey = this.getApiKey();
    if (!apiKey) {
      throw new Error('BREVO_API_KEY is not configured in environment variables');
    }

    // Clean angle brackets if present
    const cleanId = (messageId || '').replace(/[<>]/g, '').trim();
    if (!cleanId) return null;

    try {
      const url = `${this.smtpEmailsUrl}?messageId=${encodeURIComponent(cleanId)}`;
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'api-key': apiKey,
          'Accept': 'application/json'
        }
      });

      const responseBody = await response.json();
      if (!response.ok) {
        console.warn(`[BrevoService.getEmailEvents] HTTP ${response.status}:`, responseBody);
        return null;
      }

      return responseBody;
    } catch (err) {
      console.error(`[BrevoService.getEmailEvents] Failed for ${cleanId}:`, err.message);
      return null;
    }
  }
}

module.exports = new BrevoService();
